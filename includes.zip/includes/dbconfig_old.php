<?
/// database details
/*$db_host     = "localhost";
$db_name	 = "barzz";
$db_username = "root";
$db_password = "";*/

$db_host     = "localhost";
$db_name	 = "nanda";
$db_username = "root";
$db_password = "";
/*
$db_host     = "69.50.200.10";
$db_name	 = "vikram";
$db_username = "vikram";
$db_password = "vikram";
*/

$conn = mysql_connect($db_host,$db_username,$db_password) or die("Could not connect to Server" .mysql_error());
mysql_select_db($db_name) or die("Could not connect to Database" .mysql_error());

function getSqlQuery($query) {
	$result = mysql_query($query) or die(mysql_error());	
	return $result;	
}
function getSqlFetch($rs) {
	$res = mysql_fetch_assoc($rs);	
	return $res;
}
function getSqlRow($query) {
	$result = mysql_query($query) or die(mysql_error());
	$row = mysql_fetch_array($result);
	mysql_free_result($result);
	return $row;
}

function getSqlNumber($sqlQuery) {
	$query=@mysql_query($sqlQuery);
	$result=@mysql_num_rows($query);
	@mysql_free_result($query);
	return $result;
}

function getSqlField($sqlQuery,$field) {
	$isQuery = getSqlNumber($sqlQuery);
	$query = @mysql_query($sqlQuery) or die (mysql_error()."<br>INVALID QUERY: ".$sqlQuery);
	if ($isQuery>0) {
		$result=@mysql_result($query,0,$field);
	} else $result="n/a";
	@mysql_free_result($query);
	return $result;
}

function deleteFile($filepath,$filename) {
	$success = FALSE;
	if (file_exists($filepath.$filename)&&$filename!=""&&$filename!="n/a") {
		unlink ($filepath.$filename);
		$success = TRUE;
	}
	return $success;	
}

function uploadFile($file,$destDir) {
$success = FALSE;
	if (move_uploaded_file($file,$destDir))
	{
	   $success = TRUE;
	}	
return $success;
}

function paginate($start,$limit,$total,$filePath,$otherParams) {
	global $lang;

	$allPages = ceil($total/$limit);

	$currentPage = floor($start/$limit) + 1;

	$pagination = "";
	if ($allPages>10) {
		$maxPages = ($allPages>9) ? 9 : $allPages;

		if ($allPages>9) {
			if ($currentPage>=1&&$currentPage<=$allPages) {
				$pagination .= ($currentPage>4) ? " ... " : " ";

				$minPages = ($currentPage>4) ? $currentPage : 5;
				$maxPages = ($currentPage<$allPages-4) ? $currentPage : $allPages - 4;

				for($i=$minPages-4; $i<$maxPages+5; $i++) {
					$pagination .= ($i == $currentPage) ? "[".$i."] " : "<a class='linktext' href=\"".$filePath."?start=".(($i-1)*$limit).$otherParams."\">".$i."</a> ";
				}
				$pagination .= ($currentPage<$allPages-4) ? " ... " : " ";
			} else {
				$pagination .= " ... ";
			}
		}
	} else {
		for($i=1; $i<$allPages+1; $i++) {
			$pagination .= ($i==$currentPage) ? "[".$i."] " : "<a class='linktext' href=\"".$filePath."?start=".(($i-1)*$limit).$otherParams."\">".$i."</a> ";
		}
	}

	if ($currentPage>1) $pagination = "[<a class='linktext' href=\"".$filePath."?start=0".$otherParams."\">&lt;&lt;</a>] [<a  class='linktext' href=\"".$filePath."?start=".(($currentPage-2)*$limit).$otherParams."\">&lt;</a>] ".$pagination;
	if ($currentPage<$allPages) $pagination .= " [<a class='linktext' href=\"".$filePath."?start=".($currentPage*$limit).$otherParams."\">&gt;</a>] [<a class='linktext' href=\"".$filePath."?start=".(($allPages-1)*$limit).$otherParams."\">&gt;&gt;</a>]";

	echo $pagination;
}

function paginate1($start,$limit,$total,$filePath,$otherParams,$cat_name,$cat_id) {
	global $lang;

	$allPages = ceil($total/$limit);

	$currentPage = floor($start/$limit) + 1;

	$pagination = "";
	if ($allPages>10) {
		$maxPages = ($allPages>9) ? 9 : $allPages;

		if ($allPages>9) {
			if ($currentPage>=1&&$currentPage<=$allPages) {
				$pagination .= ($currentPage>4) ? " ... " : " ";

				$minPages = ($currentPage>4) ? $currentPage : 5;
				$maxPages = ($currentPage<$allPages-4) ? $currentPage : $allPages - 4;

				for($i=$minPages-4; $i<$maxPages+5; $i++) {
					$pagination .= ($i == $currentPage) ? "[".$i."] " : "<a class='linktext' href=\"".$filePath."?start=".(($i-1)*$limit).$otherParams."&cat_name=".$cat_name."&cat_id=".$cat_id."\">".$i."</a> ";
				}
				$pagination .= ($currentPage<$allPages-4) ? " ... " : " ";
			} else {
				$pagination .= " ... ";
			}
		}
	} else {
		for($i=1; $i<$allPages+1; $i++) {
			$pagination .= ($i==$currentPage) ? "[".$i."] " : "<a class='linktext' href=\"".$filePath."?start=".(($i-1)*$limit).$otherParams."&cat_name=".$cat_name."&cat_id=".$cat_id."\">".$i."</a> ";
		}
	}

	if ($currentPage>1) $pagination = "[<a class='linktext' href=\"".$filePath."?start=0".$otherParams."&cat_name=".$cat_name."&cat_id=".$cat_id."\">&lt;&lt;</a>] [<a  class='linktext' href=\"".$filePath."?start=".(($currentPage-2)*$limit).$otherParams."&cat_name=".$cat_name."&cat_id=".$cat_id."\">&lt;</a>] ".$pagination;
	if ($currentPage<$allPages) $pagination .= " [<a class='linktext' href=\"".$filePath."?start=".($currentPage*$limit).$otherParams."&cat_name=".$cat_name."&cat_id=".$cat_id."\">&gt;</a>] [<a class='linktext' href=\"".$filePath."?start=".(($allPages-1)*$limit).$otherParams."&cat_name=".$cat_name."&cat_id=".$cat_id."\">&gt;&gt;</a>]";

	echo $pagination;
}


function paginate2($start,$limit,$total,$filePath,$otherParams) {
	global $lang;

	$allPages = ceil($total/$limit);

	$currentPage = floor($start/$limit) + 1;

	$pagination = "";
	if ($allPages>10) {
		$maxPages = ($allPages>9) ? 9 : $allPages;

		if ($allPages>9) {
			if ($currentPage>=1&&$currentPage<=$allPages) {
				$pagination .= ($currentPage>4) ? " ... " : " ";

				$minPages = ($currentPage>4) ? $currentPage : 5;
				$maxPages = ($currentPage<$allPages-4) ? $currentPage : $allPages - 4;

				for($i=$minPages-4; $i<$maxPages+5; $i++) {
					$pagination .= ($i == $currentPage) ? "<span class=\"body-txt1\">[".$i."]</span> " : "<a href=\"".$filePath."?start=".(($i-1)*$limit)."&".$otherParams."\" class=\"maininfo\">".$i."</a> ";
				}
				$pagination .= ($currentPage<$allPages-4) ? " ... " : " ";
			} else {
				$pagination .= " ... ";
			}
		}
	} else {
		for($i=1; $i<$allPages+1; $i++) {
			$pagination .= ($i==$currentPage) ? "<span class=\"body-txt1\">[".$i."]</span>&nbsp;" : "<a href=\"".$filePath."?start=".(($i-1)*$limit)."&".$otherParams."\" class=\"maininfo\">".$i."</a> ";
		}
	}

	

	echo $pagination;
}

function paginate3($start,$limit,$total,$filePath,$otherParams) {
	global $lang;

	$allPages = ceil($total/$limit);

	$currentPage = floor($start/$limit) + 1;

	$pagination = "";
	if ($allPages>10) {
		$maxPages = ($allPages>9) ? 9 : $allPages;

		if ($allPages>9) {
			if ($currentPage>=1&&$currentPage<=$allPages) {
				$pagination .= ($currentPage>4) ? " ... " : " ";

				$minPages = ($currentPage>4) ? $currentPage : 5;
				$maxPages = ($currentPage<$allPages-4) ? $currentPage : $allPages - 4;

				
				$pagination .= ($currentPage<$allPages-4) ? " ... " : " ";
			} 
		}
	} 

	if ($currentPage>1) $pagination = "<span class=\"ptext\"><a href=\"".$filePath."?start=0"."&".$otherParams."\" class=\"leftlink\"><img src=images/previous.gif width=69 height=14 border=0 /></a><span class=\"ptext\"></span> <span class=\"ptext\"></span><a href=\"".$filePath."?start=".(($currentPage-1)*$limit)."&".$otherParams."\" class=\"leftlink\"></a><span class=\"ptext\"></span> ".$pagination;
	if ($currentPage<$allPages) $pagination .= "<span class=\"ptext\"></span><a href=\"".$filePath."?start=".($currentPage*$limit)."&".$otherParams."\" class=\"leftlink\"></a><span class=\"ptext\"></span> <span class=\"ptext\"></span><a href=\"".$filePath."?start=".(($allPages-1)*$limit)."&".$otherParams."\" class=\"leftlink\"><img src=images/next.gif width=47 height=14 border=0 /></a><span class=\"ptext\"></span>";

	echo $pagination;
	}

$settings=mysql_query("select * from nile_settings");
$rs_settings  = getSqlFetch($settings);
extract($rs_settings);
?>

