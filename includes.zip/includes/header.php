<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="CSS/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style4 {font-size: 13px}
-->
</style>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="35%"><img src="images/Deeptipublishers-logo.jpg" width="332" height="106" /></td>
        <td width="65%" valign="bottom"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="69">&nbsp;</td>
          </tr>
        </table>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td>&nbsp;</td>
                <td width="101" align="center" background="images/top_button.jpg" class="agentadmin"><a href="index.php" class="agentadmin">Home</a></td>
                <td width="5">&nbsp;</td>
                <td width="101" align="center" background="images/top_button.jpg" class="agentadmin"><a href="aboutus.php" class="agentadmin">About Us</a> </td>
                <td width="5">&nbsp;</td>
                <td width="101" align="center" background="images/top_button.jpg" class="agentadmin"><a href="cart.php" class="agentadmin">Shopping Cart</a> </td>
                <td width="5">&nbsp;</td>
                <td width="101" height="31" align="center" background="images/top_button.jpg" class="agentadmin"><a href="Contactus.php" class="agentadmin">Contact Us</a> </td>
              </tr>
            </table></td>
            <td width="5">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="7"><img src="images/searchleft.jpg" width="7" height="72" /></td>
        <td background="images/search_bg.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="35"><form name="search" method="post" action="search_products.php">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="8%" class="footer2 style4">Search : </td>
                  <td width="15%"><label>
                    <input type="text" name="item" value="">
                  </label></td>
                  <td width="1%">&nbsp;</td>
                  <td width="9%"><select name="category" class="textfield1">
                                    <option value="all">Select Category</option>
									<?php  $q_selproperty=mysql_query("select * from nile_category where status=1");
						             while($selproperty=mysql_fetch_array($q_selproperty))
							         {
						  			?>
                                    <option value="<?php echo $selproperty['cat_id']?>"><?php echo $selproperty['cat_name']; ?></option>
                                    <?php } ?>
                                    </select>  
                  </td>
                  <td width="67%"><input type="submit" name="Submit3" value="GO" /></td>
                </tr>
              </table>
            </form></td>
          </tr>
          <tr>
            <td height="27"><div class="avail">
              <marquee>
                Welcome to DeeptiPublication
                </marquee>
            </div></td>
          </tr>
        </table></td>
        <td width="5"><img src="images/searchright.jpg" width="5" height="72" /></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
