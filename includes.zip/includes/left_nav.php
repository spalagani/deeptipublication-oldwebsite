<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: 12px}
-->
</style>
<script type="text/javascript">
function subvalidate()
{
	var username = document.formsub.email.value;
	
	var emailFormat = /^\w(\.?[\w-])*@\w(\.?[\w-])*\.[a-zA-Z]{2,6}(\.[a-zA-Z]{2})?$/;
		if(username == "")
		{
			alert("Please enter Email ID To Subscribe");
			document.formsub.email.focus();
			return false;
		}	
		if(username!= "")
		{	
		 	var eres=username.search(emailFormat);
			if(eres == -1)
			{
				alert("Please Enter Valid Email Id ");
				document.formsub.email.focus();
				return false;
			}
		}	return true;
	
}
</script>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="204" height="33" align="left" background="images/left_heading_bg.jpg" class="add" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Categories </td>
          </tr>
          <tr>
            <td background="images/index_design_36.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="9%" height="27">&nbsp;</td>
                <td width="64%" align="left" class="footertext style1"><a href="deepti_textbooks.php" class="footertext">Text Books</a> </td>
                <td width="27%"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
              <tr>
                <td height="27">&nbsp;</td>
                <td height="27" align="left" class="footertext style1"><a href="deepti_questionbanks.php" class="footertext">Question Banks </a></td>
                <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
              <tr>
                <td height="27">&nbsp;</td>
                <td height="27" align="left" class="footertext style1"><a href="deepti_studymaterials.php" class="footertext">Study Materials</a></td>
                <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
              <tr>
                <td height="27">&nbsp;</td>
                <td height="27" align="left" class="footertext style1"><a href="deepti_eamcetbooks.php?subcategory=13" class="footertext">Eamcet</a> </td>
                <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
              <tr>
                <td height="27">&nbsp;</td>
                <td height="27" align="left" class="footertext style1"><a href="otherbooks.php?subcategory=14" class="footertext">Other books </a></td>
                <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td><img src="images/-left_bottom_bg.jpg" width="203" height="3" /></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align="center" valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>
			<fieldset>
               <legend class="points">Subscribe for Updates</legend>
			   <form action="subscribe.php" method="post" name="formsub" id="formsub" onsubmit="javascript:return subvalidate()"><table width="100%" border="0" cellspacing="2" cellpadding="0">
            <tr>
              <td height="10" colspan="2" align="left"  class="maininfo"><span class="brown_txt">Email Subscription: </span></td>
            </tr>
            <tr>
              <td colspan="2" align="left" class="brown_txt">&nbsp;</td>
              </tr>
            <tr>
              <td colspan="2" align="left" class="brown_txt"><input name="email" type="text" size="23" /></td>
              </tr>
            <tr>
              <td width="47%">&nbsp;</td>
              <td width="53%" align="left"><input type="submit" name="submit" value="submit" class="textfield" /></td>
            </tr>
            
          </table>
        </form>
		</fieldset></td>
          </tr>
		  <tr>
            <td>&nbsp;
			
</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
