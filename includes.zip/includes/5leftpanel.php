<style type="text/css">
<!--
.style1 {	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
	color: #FFFFFF;
}
-->
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><img src="images/TV2002-copy_02.jpg" width="188" height="35" /></td>
      </tr>
      <tr>
        <td><table bgcolor="#30A1DB" width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td  height="69" ><table width="100%" border="0">
              <tr>
           <td width="19%"></td>   
<td width="80%" align="left"> <select name="category" class="textfield1">
                                    <option value="">Select Category</option>
									<?php  $q_selproperty=mysql_query("select * from nile_category where status=1");
						             while($selproperty=mysql_fetch_array($q_selproperty))
							         {
						  			?>
                                    <option value="<?=$selproperty['cat_id']?>"><?php echo $selproperty['cat_name']; ?></option>
                                    <?php } ?>
                                    </select>               </td>
                <td width="1%"></td>
              </tr>
              <tr>
                <td width="19%"></td>
                <td> 
                <table width="100%" cellpadding="0" cellspacing="0"><tr>
                <td width="23%" align="left" valign="middle"><input type="text" name="name" class="textfield"></td>
                <td width="77%" align="left" valign="bottom"><input type="image" src="images/gobutton.jpg" border="0"></td>
                </tr></table></td>
                 <td align="left" valign="middle">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/TV2002-copy_06.jpg" width="188" height="24" /></td>
      </tr>
    </table></td>
  </tr>
  <?php  $selproperty=mysql_query("select * from nile_category where status=1 ");
						             while($property=mysql_fetch_array($selproperty))
							         {
						  			?>
  <tr>
    <td height="30" background="images/TV2002-copy_08.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="18%" height="30">&nbsp;</td>
        <td width="82%" align="left" style="style1"><a href="products.php?category=<?=$property['cat_id']?>" style="style1"><?php echo $property['cat_name']; ?></a></td>
      </tr>
       
    </table></td>
  </tr>
 <?php  } ?>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><img src="images/TV2002-copy_13.jpg" width="188" height="38" /></td>
      </tr>
       <?php  $selproperty=mysql_query("select * from nile_staticpages where status=1 ");
						             while($property=mysql_fetch_array($selproperty))
							         {
						  			?>
      <tr>
       <td height="30" background="images/TV2002-copy_08.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="18%" height="30">&nbsp;</td>
        <td width="82%" align="left" style="style1"><a href="staticpages.php?page=<?=$property['page_id']?>" class="style6"><?php echo $property['page_name']; ?></a></td>
      </tr>
      </table></td>
      </tr>
      <?php  } ?>
     
      <tr>
        <td><img src="images/TV2002-copy_15.jpg" width="188" height="69" /></td>
      </tr>
    </table></td>
  </tr>
</table>
