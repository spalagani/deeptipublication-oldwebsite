<?php

$degree=4;

$degreetest=8;

$intermediate=3;

$school=2;

$uni_array=array("SVU","OU","AU","ANU","KU");
$typ_array=array("Text Books","Question Banks","Test Papers");

?>