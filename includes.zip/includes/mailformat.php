<?php
$message = '
<table width="80%" border="0" cellspacing="0" cellpadding="0">
     <tr>
        <td height="6" colspan="2" align="center" valign="top"><table width="90%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="top" bgcolor="#828EB1"><table width="100%" border="0" cellspacing="1" cellpadding="2">
                  <tr>
                    <td colspan="2" align="center" bgcolor="#FFFFFF" class="subheading"><strong>REGISTRATION DETAILS </strong></td>
                  </tr>
				  <tr>
                    <td colspan="2" align="center" bgcolor="#FFFFFF" class="subheading"><strong>Welcome to Nileriver!</strong></td>
                  </tr>
				  <tr>
                    <td colspan="2" width="41%" align="center" valign="middle" bgcolor="#FFFFFF" class="subheading">Hello '.$first_name.'</td>
                  </tr>
				  <tr>
                    <td colspan="2" align="center" bgcolor="#FFFFFF" class="subheading"><strong>Thank you for registering with Nileriver. This email confirms your membership.  Your account information is:</strong></td>
                  </tr>
                  
                  <tr>
                    <td align="center" valign="middle" bgcolor="#FFFFFF" class="subheading1">Username</td>
                    <td align="center" valign="middle" bgcolor="#FFFFFF" class="subheading">'.$username.'</td>
                  </tr>
				  
				  <tr>
                    <td align="center" valign="middle" bgcolor="#FFFFFF" class="subheading1">Password</td>
                    <td align="center" valign="middle" bgcolor="#FFFFFF" class="subheading">'.$password.'</td>
                  </tr>

                  <tr>
                    <td colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" class="subheading1"><table width="100%" border="0" cellspacing="2" cellpadding="0">
                      <tr>
                        <td width="89%">&nbsp;</td>
                        <td width="11%" align="left" valign="middle">&nbsp;</td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
            </tr>
          </table>
            <br />
            <br />
            <table width="90%" border="0" cellspacing="0" cellpadding="0">
              
            </table>
			
			<br><br>
          <br />
            <br />
           
      <tr>
        <td height="6" colspan="3" align="left" valign="top"><img src="images/spacer.gif" width="1" height="1" /></td>
      </tr>
	  </form>
    </table>';
	?>