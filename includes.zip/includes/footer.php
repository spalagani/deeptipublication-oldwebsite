<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="2%" align="center">&nbsp;</td>
    <td width="13%" align="right" class="maininfo">We Are Accept&nbsp;&nbsp; </td>
    <td colspan="2" align="left"><img src="images/credit-cards.jpg" width="161" height="22" /></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
    <td align="center" class="greentext">All Rights Reserved </td>
    <td width="68%" align="right" valign="middle" class="body-txt"><table width="98%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center">&nbsp;</td>
      </tr>
    </table></td>
    <td width="17%" height="35" align="left" class="footertext">Powered By <a href="http://www.srisolutions.in" target="_blank">Srisolutions</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4" align="center">&nbsp;</td>
  </tr>
</table>
</body>
</html>
