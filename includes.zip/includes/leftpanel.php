<style type="text/css">

<!--

.style1 {	font-family: Verdana, Arial, Helvetica, sans-serif;

	font-size: 12px;

	font-weight: bold;

	color: #FFFFFF;

	text-decoration:none;

}

-->

</style>

<table width="100%" border="0" cellspacing="0" cellpadding="0">

  <tr>

    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td><img src="images/TV2002-copy_02.jpg" width="188" height="35" /></td>

      </tr>

      <tr>

        <td><table bgcolor="#30A1DB" width="100%" border="0" cellspacing="0" cellpadding="0">

          <tr>

            <td  height="69" ><form name="search" method="post" action="search_products.php"><table width="100%" border="0">

              <tr>

                <td></td>

                <td align="left" valign="bottom" height="5"></td>

                <td></td>

              </tr>

              <tr>

           <td width="19%"></td>   

<td width="80%" align="left" valign="bottom"> <select name="category" class="textfield1">

                                    <option value="all">Select Category</option>

									<?php  $q_selproperty=mysql_query("select * from nile_category where status=1");

						             while($selproperty=mysql_fetch_array($q_selproperty))

							         {

						  			?>

                                    <option value="<?php echo $selproperty['cat_id']?>"><?php echo $selproperty['cat_name']; ?></option>

                                    <?php } ?>

                                    </select>               </td>

                <td width="1%"></td>

              </tr>

              <tr>

                <td width="19%"></td>

                <td> 

                <table width="100%" cellpadding="0" cellspacing="0"><tr>

                <td width="23%" align="left" valign="middle"><input type="text" name="item" class="textfield"></td>

                <td width="77%" align="left" valign="bottom"><input type="image" src="images/gobutton.jpg" border="0"></td>

                </tr></table></td>

                 <td align="left" valign="middle">&nbsp;</td>

              </tr>

            </table>

            </form></td>

          </tr>

        </table></td>

      </tr>

      <tr>

        <td><img src="images/TV2002-copy_06.jpg" width="188" height="24" /></td>

      </tr>

    </table></td>

  </tr>

  <?php  $selproperty=mysql_query("select * from nile_category where status=1 ");

						             while($property=mysql_fetch_array($selproperty))

							         {
if($property['cat_id']==8) {
	continue;
}
						  			?>

  <tr>

    <td height="30" background="images/TV2002-copy_08.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td width="18%" height="30">&nbsp;</td>

        <td width="82%" align="left" class="style1"><a href="pages.php?category=<?php echo $property['cat_id']?>" class="style1"><?php echo $property['cat_name']; ?><?php if($property['cat_id']==7) { ?> <img src="images/new.gif" width="28" height="12" border="0" /><?php } ?></a></td>

      </tr>

       

    </table></td>

  </tr>

 <?php  } ?>

  <tr>

    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td><img src="images/TV2002-copy_13.jpg" width="188" height="38" /></td>

      </tr>

        <tr>

       <td height="30" background="images/TV2002-copy_08.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      

      <tr>

        <td width="18%" height="30">&nbsp;</td>

        <td width="82%" align="left" style="style1"><a href="keybook_download.php" class="style1">Key Books</a></td>

      </tr>

      </table></td>

      </tr>  

 <tr>

       <td height="30" background="images/TV2002-copy_08.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      

      <tr>

        <td width="18%" height="30">&nbsp;</td>

        <td width="82%" align="left" style="style1"><a href="request_catalog.php" class="style1">Request Catalog</a></td>

      </tr>

      </table></td>

      </tr>  

	 <?php  $selproperty=mysql_query("select * from nile_staticpages where status=1 ");

						             while($property=mysql_fetch_array($selproperty))

							         {

						  			?>

      

	  <tr>

       <td height="30" background="images/TV2002-copy_08.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      

      <tr>

	  

        <td width="18%" height="30">&nbsp;</td>

        <td width="82%" align="left" style="style1"><a href="staticpages.php?page=<?php echo $property['page_id']?>" class="style1"><?php echo $property['page_name']; ?></a></td>

      </tr>

      </table></td>

      </tr>

      <?php  } ?>

	 

     

      <tr>

        <td><img src="images/TV2002-copy_222.jpg" width="188" height="69" /></td>

      </tr>

	  <tr>

        <td ><table><tr><td class="textfield">Visit Counter : <?php echo $count ?></td></tr></table></td>

      </tr>

    </table></td>

  </tr>

</table>

