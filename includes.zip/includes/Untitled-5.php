
<table width="80%" border="0" cellspacing="0" cellpadding="0">
     <tr>
        <td height="6" colspan="2" align="center" valign="top"><table width="90%" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#CCCCCC">
            <tr>
              <td align="center" valign="top" 	><table width="100%" border="0" align="center" cellpadding="2" cellspacing="1" bgcolor="#FFFFFF">
                  <tr>
                    <td colspan="2" align="center"  class="subheading"></td>
                  </tr>
				  <tr align="left">
				    <td colspan="2" class="subheading"><table width="91%" border="0" cellpadding="0" cellspacing="0" background="http://202.63.102.85:82/php/nileriver/images/header_01.jpg">
  <tr>
    <td width="33%"><table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        	<td width="90%"><img src="http://202.63.102.85:82/php/nileriver/admin/images/logo_1191918845.gif" /></td>
      </tr>
    </table></td>
    <td width="37%">&nbsp;</td>
    <td width="30%" align="left" valign="middle" class="copy-text"><div align="center"> <br />
   .</div></td>
  </tr></table></td>
			    </tr>
				  <tr align="left">
				    <td colspan="2" class="subheading">&nbsp;</td>
			    </tr>
				  <tr align="left">
                    <td colspan="2" class="subheading">Welcome to Nileriver!</td>
                  </tr>
				  <tr>
                    <td colspan="2" width="41%" align="left" valign="middle"  class="subheading">Hello <strong>".$firstname."</strong></td>
                  </tr>
				  <tr>
                    <td colspan="2" align="left"  class="subheading"><p>Thank you for registering to receive information from <STRONG>Nileriver.com</STRONG>.</p></td>
                  </tr>
				  <tr><td>&nbsp;</td></tr>
				  
				  
                  <tr>
                    <td colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" class="subheading1"><table width="100%" border="0" cellspacing="2" cellpadding="0">
                      <tr>
                        <td width="100%" bgcolor="#FFFFFF"><p>Cheers,</p>
                        <p>the nileriver.com team</p></td>
                        <td width="0%" align="left" valign="middle">&nbsp;</td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
            </tr>
          </table>
            <br />
      <tr>
        <td height="6" colspan="3" align="left" valign="top"><img src="images/spacer.gif" width="1" height="1" /></td>
      </tr>
	  </form>
    </table>