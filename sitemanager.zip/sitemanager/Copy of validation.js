function ChangeBackground(what, color) {
what.style.backgroundColor=color;
}

function MouseOverMenu(what){
//what.style.cursor='hand';
ChangeBackground(what, "#F2DFD3");}

function MouseOutMenu(what){
what.style.cursor='default';
ChangeBackground(what, "#ffffff");
}

function callmsg()
{	
	var pp=confirm("Are you sure that you want to delete ?");

	if (pp)
	{
		alert("Deleted sucessfully");
		return true;		
		
	}
	else
	{
		return false;
	}
}
function checkval(chkname1)
{
	var allchkbox=document.forms['formx'].elements[chkname1];
	var countallchkbox = allchkbox.length;
	for(var i = 0; i < countallchkbox; i++)
		{
			if(allchkbox[i].checked == 0)
			document.formx.selall.checked=0;
		}
}	
function checkstate(chkname)
{
	if(document.formx.selall.checked==1)
	{
		checkall("formx",chkname,1);
		
	}
	if(document.formx.selall.checked==0)
	{
		checkall("formx",chkname,0);
	}
}	
function checkstate1(chkname)
{
	
		checkall("formx",chkname,1);
	
}	
function checkall(FormName, FieldName, CheckValue)
{
	if(!document.forms[FormName])
		return;
	var objCheckBoxes = document.forms[FormName].elements[FieldName];
	if(!objCheckBoxes)
		return;
	var countCheckBoxes = objCheckBoxes.length;
	if(!countCheckBoxes)
		objCheckBoxes.checked = CheckValue;
	else
		// set the check value for all check boxes
		for(var i = 0; i < countCheckBoxes; i++)
			objCheckBoxes[i].checked = CheckValue;
}	
//////////////////////////////////mouseover//////////////////////////////
function movepic(img_name,img_src) {
document[img_name].src=img_src;
}
///////////////////////////////Banner validation//////////////////////////
function banner()
{
	var advertiser = document.formx1.advertiser.value;
	var name = document.formx1.name.value;
	var file = document.formx1.file.value;
	var url = document.formx1.url.value;
		if(advertiser == "")
		{
			alert("Please Select any Advertiser.");
			document.formx1.advertiser.focus();
			return false;
		}
		if(name == "")
		{
			alert("Please Enter Banner Name.");
			document.formx1.name.focus();
			return false;
		}
		if(file == "")
		{
			alert("Please Upload Image.");
			document.formx1.file.focus();
			return false;
		}
		if(url == "")
		{
			alert("Please Enter Banner Url.");
			document.formx1.url.focus();
			return false;
		}
	else
	{
		document.formx1.action='banner.php?ok=add';
		document.formx1.submit();
	}

}
function banner1()
{
	
		document.formx1.action='banner.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Banner validation//////////////////////////
function ad()
{
	var name=document.formx1.name.value;
	var email = document.formx1.email.value;
	var amount = document.formx1.amount.value;
	if(name == "")
		{
			alert("Please enter Advertiser Name.");
			document.formx1.name.focus();
			return false;
		}
		else if(email == "")
		{
			alert("Please enter Advertiser Email.");
			document.formx1.email.focus();
			return false;
		}
		else if(amount == "")
		{
			alert("Please enter Amount.");
			document.formx1.amount.focus();
			return false;
		}
	else
	{
		document.formx1.action='advertiser.php?ok=add';
		document.formx1.submit();
	}

}
function ad1()
{
	
		document.formx1.action='advertiser.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////
///////////////////////////////Admin validation//////////////////////////
function validate()
{
	var firstname = document.formx1.fname.value;
	var lastname = document.formx1.lname.value;
	var username = document.formx1.username.value;
	var password = document.formx1.password.value;

		if(firstname == "")
		{
			alert("Please enter First Name.");
			document.formx1.fname.focus();
			return false;
							
		}
		if(lastname == "")
		{
			alert("Please enter Last Name.");
			document.formx1.lname.focus();
			return false;
		
		}	
		
		if(username == "")
		{
			alert("Please enter username");
			document.formx1.username.focus();
			return false;
			
					
		}
		if(password == "")
		{
			alert("Please enter password.");
			document.formx1.password.focus();
			return false;
				
		}
	else
	{
		document.formx1.action='admin.php?ok=add';
		document.formx1.submit();
	}

}
////////////////////////////////End //////////////////////////////////////////////////
///////////////////////////////Banner validation//////////////////////////
function banner()
{
	var name = document.formx1.name.value;

		if(name == "")
		{
			alert("Please enter Banner Name.");
			document.formx1.name.focus();
			return false;
		}
	else
	{
		document.formx1.action='banner.php?ok=add';
		document.formx1.submit();
	}

}
function banner1()
{
	
		document.formx1.action='banner.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Banner validation//////////////////////////
function ad()
{
	var name=document.formx1.name.value;
	var email = document.formx1.email.value;
	var amount = document.formx1.amount.value;
	if(name == "")
		{
			alert("Please enter Advertiser Name.");
			document.formx1.name.focus();
			return false;
		}
		else if(email == "")
		{
			alert("Please enter Advertiser Email.");
			document.formx1.email.focus();
			return false;
		}
		else if(amount == "")
		{
			alert("Please enter Amount.");
			document.formx1.amount.focus();
			return false;
		}
	else
	{
		document.formx1.action='advertiser.php?ok=add';
		document.formx1.submit();
	}

}
function ad1()
{
	
		document.formx1.action='advertiser.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////
///////////////////////////////Events validation//////////////////////////
function events()
{
	
	var title = document.formx1.title.value;
	var image = document.formx1.image.value;
	var description = document.formx1.description.value;

		if(title == "")
		{
			alert("Please enter Title.");
			document.formx1.title.focus();
			return false;
							
		}
		if(image == "")
		{
			alert("Please enter Image.");
			document.formx1.image.focus();
			return false;
		
		}
		if(description == "")
		{
			alert("Please enter Description.");
			document.formx1.description.focus();
			return false;
		
		}
				
	else
	{
		document.formx1.action='events.php?ok=add';
		document.formx1.submit();
	}

}
function events1()
{
	
		document.formx1.action='events.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

////////////////////////////////Kitty validation/////////////////////////////
function kitty(){
	var k=document.formx.kitty.value;	
	alert("Hi");
		if(k == "")
		{
			alert("Please enter Kitty Amount");
			document.formx.kitty.focus();
			return false;
		
		}	
		else
		{
			document.formx.action='kitty.php?ok=edit';
			document.formx.submit();
		}

}

////////////////////////////////End///////////////////////////////////////////

///////////////////////////////News validation//////////////////////////
function news()
{
	
	var news_title = document.formx1.news_title.value;
	//var news_desc = document.formx1.news_desc.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(news_title == "")
		{
			alert("Please enter News Title.");
			document.formx1.news_title.focus();
			return false;
							
		}
		/*if(news_desc == "")
		{
			alert("Please enter News Desc.");
			document.formx1.news_desc.focus();
			return false;
		
		}	*/
		
	else
	{
		document.formx1.action='news.php?ok=add';
		document.formx1.submit();
	}

}
function news1()
{
	
		document.formx1.action='news.php?ok=edit';
		document.formx1.submit();
	
}

////////////////////////////////End //////////////////////////////////////////////////
//////////////////////////Blog validation/////////////////////////////////////////
function blog()
{
	
	//var news_title = document.formx1.news_title.value;
	//var news_desc = document.formx1.news_desc.value;
	//var cat_desc = document.formx1.cat_desc.value;

		/*if(news_title == "")
		{
			alert("Please enter News Title.");
			document.formx1.news_title.focus();
			return false;
							
		}*/
		/*if(news_desc == "")
		{
			alert("Please enter News Desc.");
			document.formx1.news_desc.focus();
			return false;
		
		}	*/
		
	//else
	//{
		document.formx1.action='blog.php?ok=add';
		document.formx1.submit();
	//}

}
function blog1()
{
	
		document.formx1.action='blog.php?ok=edit';
		document.formx1.submit();
	
}

////////////////////////////End of blog validation//////////////////////////////



//////////////////////////comment validation/////////////////////////////////////////
function comment_blog()
{
	
	//var news_title = document.formx1.news_title.value;
	//var news_desc = document.formx1.news_desc.value;
	//var cat_desc = document.formx1.cat_desc.value;

		/*if(news_title == "")
		{
			alert("Please enter News Title.");
			document.formx1.news_title.focus();
			return false;
							
		}*/
		/*if(news_desc == "")
		{
			alert("Please enter News Desc.");
			document.formx1.news_desc.focus();
			return false;
		
		}	*/
		
	//else
	//{
		document.formx1.action='blog_comment.php?ok=add';
		document.formx1.submit();
	//}

}
function comment_blog1()
{
	
		document.formx1.action='blog_comment.php?ok=edit';
		document.formx1.submit();
	
}

////////////////////////////End of comment validation//////////////////////////////





///////////////////////////////News user validation//////////////////////////
function news_user()
{
	
	var name = document.formx1.name.value;
	var email = document.formx1.email.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(name == "")
		{
			alert("Please enter Name.");
			document.formx1.name.focus();
			return false;
							
		}
		if(email == "")
		{
			alert("Please enter Email.");
			document.formx1.email.focus();
			return false;
		
		}	
		
	else
	{
		document.formx1.action='newsletter_users.php?ok=add';
		document.formx1.submit();
	}

}
function news_user1()
{
	
		document.formx1.action='newsletter_users.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Category validation//////////////////////////
function category()
{
	
	var catname = document.formx1.catname.value;
	var cat_desc = document.formx1.cat_desc.value;
	var cat_metakeyword = document.formx1.cat_metakeyword.value;
	var cat_metadesc = document.formx1.cat_metadesc.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(catname == "")
		{
			alert("Please enter Name.");
			document.formx1.catname.focus();
			return false;
		
		}	
		
		if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
		}
		
		if(cat_metakeyword == "")
		{
			alert("Please enter Category Meta keyword");
			document.formx1.cat_metakeyword.focus();
			return false;
		}
		
		if(cat_metadesc == "")
		{
			alert("Please enter Category Meta Description");
			document.formx1.cat_metadesc.focus();
			return false;
		}
		
	else
	{
		document.formx1.action='categories.php?ok=add';
		document.formx1.submit();
	}

}
function category1()
{
	
		document.formx1.action='categories.php?ok=edit';
		document.formx1.submit();
	
}
/////////////////////////////////////////////
///////////////////////////////Category validation//////////////////////////
function links_category()
{
	
	var catname = document.formx1.catname.value;
	var cat_desc = document.formx1.cat_desc.value;
	var cat_metakeyword = document.formx1.cat_metakeyword.value;
	var cat_metadesc = document.formx1.cat_metadesc.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(catname == "")
		{
			alert("Please enter Name.");
			document.formx1.catname.focus();
			return false;
		
		}	
		
		if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
		}
		
		if(cat_metakeyword == "")
		{
			alert("Please enter Category Meta keyword");
			document.formx1.cat_metakeyword.focus();
			return false;
		}
		
		if(cat_metadesc == "")
		{
			alert("Please enter Category Meta Description");
			document.formx1.cat_metadesc.focus();
			return false;
		}
		
	else
	{
		document.formx1.action='links_categories.php?ok=add';
		document.formx1.submit();
	}

}
function links_category1()
{
	
		document.formx1.action='links_categories.php?ok=edit';
		document.formx1.submit();
	
}

function nileinfo_category()
{
	alert("success");
	var catname = document.formx1.catname.value;
	var cat_desc = document.formx1.cat_desc.value;
	var cat_metakeyword = document.formx1.cat_metakeyword.value;
	var cat_metadesc = document.formx1.cat_metadesc.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(catname == "")
		{
			alert("Please enter Name.");
			document.formx1.catname.focus();
			return false;
		
		}	
		
		if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
		}
		
		if(cat_metakeyword == "")
		{
			alert("Please enter Category Meta keyword");
			document.formx1.cat_metakeyword.focus();
			return false;
		}
		
		if(cat_metadesc == "")
		{
			alert("Please enter Category Meta Description");
			document.formx1.cat_metadesc.focus();
			return false;
		}
		
	else
	{
		document.formx1.action='nileinfo_categories.php?ok=add';
		document.formx1.submit();
	}

}
function nileinfo_category1()
{
	
		document.formx1.action='nileinfo_categories.php?ok=edit';
		document.formx1.submit();
	
}

function events2()
{
	var eventname = document.formx1.eventname.value;
	var cname =document.formx1.cname.value;
	var sdesc =document.formx1.sdesc.value;
	var url =document.formx1.url.value;
	var desc =document.formx1.desc.value;
	var tag =document.formx1.tag.value;
	var category1 =document.formx1.category1.value;
	var category =document.formx1.category.value;
	var subcat_id =document.formx1.subcat_id.value;
	var picture =document.formx1.picture.value;
	var venuename =document.formx1.venuename.value;
	var address =document.formx1.address.value;
	var city =document.formx1.city.value;
	var type =document.formx1.type.value;
	
	if(eventname == "")
		{
			alert("Please enter Event Name");
			document.formx1.eventname.focus();
			return false;
		}
		
		else if(cname=="")
	{
			alert("Please enter Contact Phone");
			document.formx1.cname.focus();
			return false;
		}
		
		else if(sdesc=="")
	{
			alert("Please enter Introduction");
			document.formx1.sdesc.focus();
			return false;
		}
		else if(url=="")
	{
			alert("Please enter Website url");
			document.formx1.url.focus();
			return false;
		}
		else if(desc=="")
	{
			alert("Please enter Profile");
			document.formx1.desc.focus();
			return false;
		}
		else if(tag=="")
	{
			alert("Please enter Tags");
			document.formx1.tag.focus();
			return false;
		}
		else if(category1=="")
	{
			alert("Please enter Main category");
			document.formx1.category1.focus();
			return false;
		}
		else if(category=="")
	{
			alert("Please enter category");
			document.formx1.category.focus();
			return false;
		}
		else if(subcat_id=="")
	{
			alert("Please enter Sub category");
			document.formx1.subcat_id.focus();
			return false;
		}
		else if(picture=="")
	{
			alert("Please enter picture");
			document.formx1.picture.focus();
			return false;
		}
		else if(venuename=="")
	{
			alert("Please enter venuename");
			document.formx1.venuename.focus();
			return false;
		}
		else if(address=="")
	{
			alert("Please enter Address");
			document.formx1.address.focus();
			return false;
		}
		else if(city=="")
	{
			alert("Please enter City");
			document.formx1.city.focus();
			return false;
		}
		else if(type=="")
	{
			alert("Please enter Type");
			document.formx1.type.focus();
			return false;
		}
		else if(vphone=="")
	{
			alert("Please enter Phone number");
			document.formx1.vphone.focus();
			return false;
		}
		
		else
		{
	document.formx1.action='events.php?ok=add';
	document.formx1.submit();
}
}

function events1()
{
	
		document.formx1.action='events.php?ok=edit';
		document.formx1.submit();
	
}

////////////////////////////////////////////////////////

function pages()
{
	
	var pagename = document.formx1.pagename.value;
	var page_desc = document.formx1.page_desc.value;
		
		if(pagename == 0)
		{
			alert("Please Select any Page.");
			document.formx1.pagename.focus();
			return false;
		
		}
		
		if(page_desc == "")
		{
			alert("Please enter Page description.");
			document.formx1.page_desc.focus();
			return false;
		
		}	
		
	else
	{
		document.formx1.action='staticpages.php?ok=add';
		document.formx1.submit();
	}

}
function pages1()
{
	
		document.formx1.action='staticpages.php?ok=edit';
		document.formx1.submit();
	
}

function items()
{
	
	var itemname = document.formx1.itemname.value;
	var category = document.formx1.category.value;
	var file = document.formx1.file.value;
	var have_hins = document.formx1.have_hins.value;
	var audio_file = document.formx1.audio_file.value;
	
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(itemname == "")
		{
			alert("Please enter Name.");
			document.formx1.itemname.focus();
			return false;
		
		}
		
		if(category == 0)
		{
			alert("Please select Category.");
			document.formx1.category.focus();
			return false;
		
		}	
		
		if(file == "")
		{
			alert("Please upload image.");
			document.formx1.file.focus();
			return false;
		
		}
		
/*		for (i=0;i<have_hins.length;i++) {
			if (have_hins[i].checked == 0) {
			alert("success");
	}
}
*/		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='items.php?ok=add';
		document.formx1.submit();
	}

}
function items1()
{
	
		document.formx1.action='items.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////
function links_items()
{
	
	var itemname = document.formx1.itemname.value;
	var category = document.formx1.category.value;
	var file = document.formx1.file.value;
	var have_hins = document.formx1.have_hins.value;
	var audio_file = document.formx1.audio_file.value;
	
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(itemname == "")
		{
			alert("Please enter Name.");
			document.formx1.itemname.focus();
			return false;
		
		}
		
		if(category == 0)
		{
			alert("Please select Category.");
			document.formx1.category.focus();
			return false;
		
		}	
		
		if(file == "")
		{
			alert("Please upload image.");
			document.formx1.file.focus();
			return false;
		
		}
		
/*		for (i=0;i<have_hins.length;i++) {
			if (have_hins[i].checked == 0) {
			alert("success");
	}
}
*/		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='links_items.php?ok=add';
		document.formx1.submit();
	}

}
function links_items1()
{
	
		document.formx1.action='links_items.php?ok=edit';
		document.formx1.submit();
	
}


function nileinfo_items()
{
	
	var itemname = document.formx1.itemname.value;
	var category = document.formx1.category.value;
	var file = document.formx1.file.value;
	var have_hins = document.formx1.have_hins.value;
	var audio_file = document.formx1.audio_file.value;
	
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(itemname == "")
		{
			alert("Please enter Name.");
			document.formx1.itemname.focus();
			return false;
		
		}
		
		if(category == 0)
		{
			alert("Please select Category.");
			document.formx1.category.focus();
			return false;
		
		}	
		
		if(file == "")
		{
			alert("Please upload image.");
			document.formx1.file.focus();
			return false;
		
		}
		
/*		for (i=0;i<have_hins.length;i++) {
			if (have_hins[i].checked == 0) {
			alert("success");
	}
}
*/		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='nileinfo_items.php?ok=add';
		document.formx1.submit();
	}

}
function nileinfo_items1()
{
	
		document.formx1.action='nileinfo_items.php?ok=edit';
		document.formx1.submit();
	
}


function quotes()
{
	
	var quote = document.formx1.quote.value;
	
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(quote == "")
		{
			alert("Please enter Quote.");
			document.formx1.quote.focus();
			return false;
		
		}
		
		
/*		for (i=0;i<have_hins.length;i++) {
			if (have_hins[i].checked == 0) {
			alert("success");
	}
}
*/		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='quotes.php?ok=add';
		document.formx1.submit();
	}

}
function quotes1()
{
	
		document.formx1.action='quotes.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Admin validation//////////////////////////
function admin()
{
	
	var fname = document.formx1.fname.value;
	var lname = document.formx1.lname.value;
	var username = document.formx1.username.value;
	var password = document.formx1.password.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(fname == "")
		{
			alert("Please enter First Name.");
			document.formx1.fname.focus();
			return false;
		
		}	
		if(lname == "")
		{
			alert("Please enter Last Name.");
			document.formx1.lname.focus();
			return false;
		
		}	
		if(username == "")
		{
			alert("Please enter username.");
			document.formx1.username.focus();
			return false;
		
		}	
		if(password == "")
		{
			alert("Please enter password.");
			document.formx1.password.focus();
			return false;
		
		}	

		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='admin_edit.php?ok=add';
		document.formx1.submit();
	}

}
function admin1()
{
	
		document.formx1.action='admin_edit.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////


///////////////////////////////auction validation//////////////////////////
function auction()
{
	
	var name = document.formx1.name.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(name == "")
		{
			alert("Please enter Name.");
			document.formx1.name.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='auction.php?ok=add';
		document.formx1.submit();
	}

}
function auction1()
{
	
		document.formx1.action='auction.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////


///////////////////////////////auction validation//////////////////////////
function page()
{
	
	var name = document.formx1.name.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(name == "")
		{
			alert("Please enter Name.");
			document.formx1.name.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='cms.php?ok=add';
		document.formx1.submit();
	}

}
function page1()
{
	
		document.formx1.action='cms.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////



///////////////////////////////auction validation//////////////////////////
function precomm()
{
	
	var name = document.formx1.name.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(name == "")
		{
			alert("Please enter Name.");
			document.formx1.name.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='auction.php?ok=add';
		document.formx1.submit();
	}

}
function precomm1()
{
	
		document.formx1.action='precomm.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////


///////////////////////////////Sponsor validation//////////////////////////
function sponsor()
{
	
	var email = document.formx1.email.value;
	var password = document.formx1.password.value;
	var first_name = document.formx1.first_name.value;
	var last_name = document.formx1.last_name.value;
	var company_name = document.formx1.company_name.value;
	var company_address = document.formx1.company_address.value;
	var description = document.formx1.description.value;
	var city = document.formx1.city.value;
	var state = document.formx1.state.value;
	var zip = document.formx1.zip.value;
	var phone = document.formx1.phone.value;
	var primary_role = document.formx1.primary_role.value;
	var biz_desc = document.formx1.biz_desc.value;
	var biz_loc = document.formx1.biz_loc.value;
	var county = document.formx1.county.value;
	var biz_type = document.formx1.biz_type.value;
	var keywords = document.formx1.keywords.value;
	var invest = document.formx1.invest.value;
	var time_frame = document.formx1.time_frame.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(email == "")
		{
			alert("Please enter Email.");
			document.formx1.email.focus();
			return false;
							
		}
		if(password == "")
		{
			alert("Please enter Password.");
			document.formx1.password.focus();
			return false;
							
		}
		if(first_name == "")
		{
			alert("Please enter First Name.");
			document.formx1.first_name.focus();
			return false;
							
		}
		if(last_name == "")
		{
			alert("Please enter Last Name.");
			document.formx1.last_name.focus();
			return false;
							
		}
		if(company_name == "")
		{
			alert("Please enter Company Name.");
			document.formx1.company_name.focus();
			return false;
							
		}
		if(company_address == "")
		{
			alert("Please enter Company Address.");
			document.formx1.company_address.focus();
			return false;
							
		}
		if(description == "")
		{
			alert("Please enter Description.");
			document.formx1.description.focus();
			return false;
							
		}
		if(city == "")
		{
			alert("Please enter City.");
			document.formx1.city.focus();
			return false;
							
		}
		if(state == "")
		{
			alert("Please enter State.");
			document.formx1.state.focus();
			return false;
							
		}
		if(zip == "")
		{
			alert("Please enter Zip.");
			document.formx1.zip.focus();
			return false;
							
		}
		if(phone == "")
		{
			alert("Please enter Telephone.");
			document.formx1.phone.focus();
			return false;
							
		}
		if(primary_role == "")
		{
			alert("Please enter Primary Role.");
			document.formx1.primary_role.focus();
			return false;
							
		}
		if(biz_desc == "")
		{
			alert("Please enter Business Description.");
			document.formx1.biz_desc.focus();
			return false;
							
		}
		if(biz_loc == "")
		{
			alert("Please enter Business Location.");
			document.formx1.biz_loc.focus();
			return false;
							
		}
		if(county == "")
		{
			alert("Please enter County.");
			document.formx1.county.focus();
			return false;
							
		}
		if(biz_type == "")
		{
			alert("Please enter Business Type.");
			document.formx1.biz_type.focus();
			return false;
							
		}
		if(keywords == "")
		{
			alert("Please enter Keywords.");
			document.formx1.keywords.focus();
			return false;
							
		}
		if(invest == "")
		{
			alert("Please enter Invest.");
			document.formx1.invest.focus();
			return false;
							
		}
		if(time_frame == "")
		{
			alert("Please enter Time Frame.");
			document.formx1.time_frame.focus();
			return false;
							
		}
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
		}*/
		document.formx1.action='sponsors.php?ok=add';
		document.formx1.submit();
}
function sponsor1()
{
	
		document.formx1.action='sponsors.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////


///////////////////////////////Request Info validation//////////////////////////
function fcategory()
{
	
	var name = document.formx1.name.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(name == "")
		{
			alert("Please enter Category Name.");
			document.formx1.name.focus();
			return false;
							
		}
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
		}*/
	else
	{
		document.formx1.action='fcategories.php?ok=add';
		document.formx1.submit();
	}

}
function fcategory1()
{
	
		document.formx1.action='fcategories.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Listings validation//////////////////////////
function reqinfo()
{
	
	var first_name = document.formx1.first_name.value;
	var last_name = document.formx1.last_name.value;
	var email = document.formx1.email.value;
	var phone = document.formx1.phone.value;
	var timetocall = document.formx1.timetocall.value;
	var address = document.formx1.address.value;
	var city = document.formx1.city.value;
	var state = document.formx1.state.value;
	var zip = document.formx1.zip.value;
	var capital = document.formx1.capital.value;
	var timeframe = document.formx1.timeframe.value;
	var message = document.formx1.message.value;
	var location = document.formx1.location.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(first_name == "")
		{
			alert("Please enter First Name.");
			document.formx1.first_name.focus();
			return false;
							
		}
		if(last_name == "")
		{
			alert("Please enter Last Name.");
			document.formx1.last_name.focus();
			return false;
							
		}
		if(email == "")
		{
			alert("Please enter Email.");
			document.formx1.email.focus();
			return false;
							
		}
		if(phone == "")
		{
			alert("Please enter Telephone No.");
			document.formx1.phone.focus();
			return false;
							
		}
		if(timetocall == "")
		{
			alert("Please enter Best Timetocall.");
			document.formx1.timetocall.focus();
			return false;
							
		}
		if(address == "")
		{
			alert("Please enter Address.");
			document.formx1.address.focus();
			return false;
							
		}
		if(city == "")
		{
			alert("Please enter City.");
			document.formx1.city.focus();
			return false;
							
		}
		if(state == "")
		{
			alert("Please enter State.");
			document.formx1.state.focus();
			return false;
							
		}
		if(zip == "")
		{
			alert("Please enter Zip.");
			document.formx1.zip.focus();
			return false;
							
		}
		if(capital == "")
		{
			alert("Please enter Capital.");
			document.formx1.capital.focus();
			return false;
							
		}
		if(timeframe == "")
		{
			alert("Please enter Timeframe.");
			document.formx1.timeframe.focus();
			return false;
							
		}
		if(message == "")
		{
			alert("Please enter Message.");
			document.formx1.message.focus();
			return false;
							
		}
		if(location == "")
		{
			alert("Please enter Location.");
			document.formx1.location.focus();
			return false;
							
		}
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
		}*/
	else
	{
		document.formx1.action='reqinfo.php?ok=add';
		document.formx1.submit();
	}

}
function reqinfo1()
{
	
		document.formx1.action='reqinfo.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Category validation//////////////////////////
function fsubcategory()
{
	
	var name = document.formx1.name.value;
	//var cat_desc = document.formx1.cat_desc.value;
		if(name == "")
		{
			alert("Please enter SubCategory name.");
			document.formx1.name.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='fsubcategories.php?ok=add';
		document.formx1.submit();
	}

}
function fsubcategory1()
{
	
		document.formx1.action='fsubcategories.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////


///////////////////////////////Auction validation//////////////////////////
function sauction()
{
	
	var name = document.formx1.name.value;
	//var cat_desc = document.formx1.cat_desc.value;
		if(name == "")
		{
			alert("Please enter name.");
			document.formx1.name.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='sellers.php?ok=add';
		document.formx1.submit();
	}

}
function sauction1()
{
	
		document.formx1.action='sellers.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////


//////////////////////////////Value Reports validation//////////////////////////
function valuetype()
{
	var name = document.formx1.name.value;
	var report_type = document.formx1.report_type.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(report_type == "")
		{
			alert("Please enter Report type.");
			document.formx1.report_type.focus();
			return false;
							
		}
		if(name == "")
		{
			alert("Please enter Report name.");
			document.formx1.name.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='valuetypes.php?ok=add';
		document.formx1.submit();
	}

}
function valuetype1()
{
	
		document.formx1.action='valuetypes.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Listings validation//////////////////////////
function listings()
{
	
	var name = document.formx1.name.value;
	var description = document.formx1.description.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(name == "")
		{
			alert("Please enter Listing Name.");
			document.formx1.name.focus();
			return false;
							
		}
		if(description == "")
		{
			alert("Please enter Description.");
			document.formx1.description.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='listings.php?ok=add';
		document.formx1.submit();
	}

}
function listings1()
{
	
		document.formx1.action='listings.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Ad type validation//////////////////////////
function adtype()
{
	
	var name = document.formx1.name.value;
	var description = document.formx1.description.value;
	var price = document.formx1.price.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(name == "")
		{
			alert("Please enter Ad Type name.");
			document.formx1.name.focus();
			return false;
							
		}
		if(description == "")
		{
			alert("Please enter Description.");
			document.formx1.description.focus();
			return false;
		}	
		if(price == "")
		{
			alert("Please enter Price.");
			document.formx1.price.focus();
			return false;
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='adtypes.php?ok=add';
		document.formx1.submit();
	}

}
function adtype1()
{
	
		document.formx1.action='adtypes.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////


///////////////////////////////Value type validation//////////////////////////
function valuetype()
{
	
	var name = document.formx1.name.value;
	var description = document.formx1.description.value;
	var price = document.formx1.price.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(name == "")
		{
			alert("Please enter Valuation Type name.");
			document.formx1.name.focus();
			return false;
							
		}
		if(description == "")
		{
			alert("Please enter Description.");
			document.formx1.description.focus();
			return false;
		}	
		if(price == "")
		{
			alert("Please enter Price.");
			document.formx1.price.focus();
			return false;
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='valuecost.php?ok=add';
		document.formx1.submit();
	}

}
function valuetype1()
{
	
		document.formx1.action='valuecost.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Banner validation//////////////////////////
function banner()
{
	var name = document.formx1.name.value;

		if(name == "")
		{
			alert("Please enter Banner Name.");
			document.formx1.name.focus();
			return false;
		}
	else
	{
		document.formx1.action='banner.php?ok=add';
		document.formx1.submit();
	}

}
function banner1()
{
	
		document.formx1.action='banner.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Sub Category validation//////////////////////////
function subcategory()
{
	
	var catid = document.formx1.catid.value;
	var subcat_name = document.formx1.subcat_name.value;
	var subcat_smdec = document.formx1.subcat_smdesc.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(catid == "")
		{
			alert("Please enter Category Name.");
			document.formx1.catid.focus();
			return false;
							
		}
		if(subcat_name == "")
		{
			alert("Please enter Sub Category Name.");
			document.formx1.subcat_name.focus();
			return false;
							
		}
		if(subcat_smdec == "")
		{
			alert("Please enter SubCategory Small Desc.");
			document.formx1.subcat_smdesc.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='subcategories.php?ok=add';
		document.formx1.submit();
	}

}
function subcategory1()
{
	
		document.formx1.action='subcategories.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Product validation//////////////////////////
function product()
{

	var catid = document.formx1.catid.value;
	var subcat_id = document.formx1.subcat_id.value;
	var prod_name = document.formx1.prod_name.value;
	var prod_smdesc = document.formx1.prod_smdesc.value;

		if(catid == "")
		{
			alert("Please enter Category Name.");
			document.formx1.catid.focus();
			return false;
							
		}
		if(subcat_id == "")
		{
			alert("Please enter Sub Category Name.");
			document.formx1.subcat_id.focus();
			return false;
							
		}
		if(prod_name == "")
		{
			alert("Please enter Product Name.");
			document.formx1.prod_name.focus();
			return false;
		
		}	
		
		if(prod_smdesc == "")
		{
			alert("Please enter Product Desc");
			document.formx1.prod_smdesc.focus();
			return false;
			
					
		}
		
	else
	{
		document.formx1.action='products.php?ok=add';
		document.formx1.submit();
	}

}
function product1()
{
	
		document.formx1.action='products.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Video validation//////////////////////////
function videos()
{
	var name = document.formx1.name.value;

		if(name == "")
		{
			alert("Please enter Video Name.");
			document.formx1.name.focus();
			return false;
		
		}	
		
		
		
	else
	{
		document.formx1.action='uploadvideo.php?ok=add';
		document.formx1.submit();
	}

}
function video1()
{
	
		document.formx1.action='uploadvideo.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

function IsNumeric(strString)
   
   {
   var strValidChars = "0123456789.,";
   var strChar;
   var blnResult = true;

   
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
         {
         blnResult = false;
         }
      }
   return blnResult;
   }
  

///////////////////////////////////////////prize validation////////////////////////////////////
function prizevalidate()
{
	
var itemname1 = document.formx.itemname.value;
var brandname1 = document.formx.brandname.value;
var retail_val1 = document.formx.retail_val.value;
var sdesc1 = document.formx.sdesc.value;
var ldesc1 = document.formx.ldesc.value;
var point1 = document.formx.point.value;
/*var ext2 = document.formx.shimage.value;
var ext = document.formx.smimage.value;
var ext1 = document.formx.lrimage.value;
ext1 = ext1.substring(ext1.length-3,ext1.length);
ext1 = ext1.toLowerCase();

ext = ext.substring(ext.length-3,ext.length);
ext = ext.toLowerCase();
ext2 = ext2.substring(ext2.length-3,ext2.length);
ext2 = ext2.toLowerCase();*/

	if (itemname1 == "")
	{
		alert("Please Enter Item Name.");
		document.formx.itemname.focus();
		return false;
	}
	if (brandname1 == "")
	{
		alert("Please Enter Brand Name.");
		document.formx.brandname.focus();
		return false;
	}
	if (retail_val1 == "")
	{
		alert("Please Enter Retail Price.");
		document.formx.retail_val.focus();
		return false;
	}
	if (retail_val1!="")
	{
		var res = IsNumeric(retail_val1);
		if(res==false)
		{
			alert("Please Enter numeric values in retail price.");
			document.formx.retail_val.value ="";
			document.formx.retail_val.focus();
			return false;
		}
	}	
	if (point1 == "")
	{
		alert("Please Enter Points Awarded.");
		document.formx.point.focus();
		return false;
	}
	if (point1!="")
	{
		var res = IsNumeric(point1);
		if(res==false)
		{
			alert("Please Enter numeric values in Points.");
			document.formx.point.value ="";
			document.formx.point.focus();
			return false;
		}
	}	
	/*if((ext2 != 'jpg') && (ext2 != 'gif')) 
	{
  		alert('You selected a .'+ ext2 + ' file; please select shoe image a .jpg or .gif file');
		return false;
     }
	if((ext != 'jpg') && (ext != 'gif')) 
	{
  		alert('You selected a .'+ ext + ' file; please select small a .jpg or .gif file');
		return false;
    }
	if((ext1 != 'jpg') && (ext1 != 'gif')) 
	{
  		alert('You selected a .'+ ext1 + ' file; please select large a .jpg or .gif file');
		return false;
    }*/
	if (sdesc1 == "")
	{
		alert("Please Enter Small Description.");
		document.formx.sdesc.focus();
		return false;
	}
	else if (ldesc1 == "")
	{
		alert("Please Enter Large Description.");
		document.formx.ldesc.focus();
		return false;
	}	
	

     
	else
	{
		
		document.formx.submit();	
	}	
}

function IsNumeric(strString)
   
   {
   var strValidChars = "0123456789.,";
   var strChar;
   var blnResult = true;

   
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
         {
         blnResult = false;
         }
      }
   return blnResult;
   }
 
 
/////////////////////////////////////////////inventorypart///////////////////////////////////////////////
var OpenSubX = (screen.width/2)-5;
	var OpenSubY = (screen.height/2)-100;
	var pos = "left="+OpenSubX+",top="+OpenSubY;

function OpenSub(x)
{
		OpenSub1Window = window.open("calendar.php?id="+x ,"not","width=190,height=165,"+pos);
}
function tota()
{
	var qty21=parseFloat(document.formx.qty.value);
	var price21=parseFloat(document.formx.price.value);
	var tax21=parseFloat(document.formx.tax.value);
	document.formx.total.value= parseFloat((price21+tax21)*qty21);
	
}
function tota1()
{
	var uqty=parseFloat(document.formx.uqtyorder.value);
	var uprice=parseFloat(document.formx.uprice.value);
	var utax=parseFloat(document.formx.utax.value);
	document.formx.utotal.value= parseFloat((uprice+utax)*uqty);
	
}
function isDate(dateStr) {

var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
var matchArray = dateStr.match(datePat); // is the format ok?

if (matchArray == null) {
alert("Please enter date as either mm/dd/yyyy or mm-dd-yyyy.");


return false;
}

month = matchArray[1]; // p@rse date into variables
day = matchArray[3];
year = matchArray[5];

if (month < 1 || month > 12) { // check month range
alert("Month must be between 1 and 12.");
return false;
}

if (day < 1 || day > 31) {
alert("Day must be between 1 and 31.");
return false;
}

if ((month==4 || month==6 || month==9 || month==11) && day==31) {
alert("Month "+month+" doesn`t have 31 days!")
return false;
}

if (month == 2) { // check for february 29th
var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
if (day > 29 || (day==29 && !isleap)) {
alert("February " + year + " doesn`t have " + day + " days!");
return false;
}
}
return true; // date is valid
}

///////////////////////////////////////////////edit system///////////////////////////////////////////////

function IsSpecialChar(strString)
   
   {
   var strValidChars = "\'\"";
   var strChar;
   var blnResult = true; 

   
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) != -1)
         {
         blnResult = false;
         }
      }
   return blnResult;
   }
function sysvalidate()
	{	
		//alert("hi");
		var sysname=document.formx.name.value;
		if(sysname=="")
		{
			alert("Please fillup the System name.");
			document.formx.name.focus();
			return false;
		}
		if(sysname != "")
		{
		var res = IsSpecialChar(sysname); 
					if(res==false)
					{
					alert("System name contains special characters like \' and \". \nThese are not allowed.\n Please remove them and try again.");
					sysname ="";
					document.formx.name.focus();
					return false;
					}
		}
		else
		{
			//document.formx.action='addmsodisney.php?ok=1';
			document.formx.submit();
			//return true;
		}
	}
	function sysvalidate1()
	{	
		//alert("hi");
		var subsysname=document.formx.subsysname.value;
		if(subsysname=="")
		{
			alert("Please fillup the Subsystem name.");
			document.formx.subsysname.focus();
			return false;
		}
		if(subsysname != "")
		{
		var res = IsSpecialChar(subsysname); 
					if(res==false)
					{
					alert("Sub System name contains special characters like \' and \". \nThese are not allowed.\n Please remove them and try again.");
					subsysname ="";
					document.formx.subsysname.focus();
					return false;
					}
		}
		else
		{
			//document.formx.action='addmsodisney.php?ok=4';
			document.formx.submit();
			//return true;
		}
	}
	