<?php
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
include "../includes/class.phpmailer.php";
include "../includes/class.smtp.php";
include("FCKeditor/fckeditor.php");
$new_array=array("Lecture","Teachers","Corresponding","Students");
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />

<script language="javascript" src='validation.js'></script>

<script type="text/javascript">
//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')
// And the language we need to use in the editor.
var _editor_lang = "en";
//var _editor_url  = "/brwrap/admin/xinha/";
var _editor_url = "xinha/";
</script>
<!-- Load up the actual editor core -->
<script type="text/javascript" src="xinha/htmlarea.js"></script>
<script type="text/javascript">
/*var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'
 ];*/
 var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'
];
/************************************************************************
 * Names of the textareas you will be turning into editors
 ************************************************************************/
var xinha_editors =
[
   'news_desc'
];
/************************************************************************
 * Initialisation function
 ************************************************************************/
function xinha_init()
{
  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)
  //var _editor_url  = document.location.href.replace(/xinha\*/, '');
 // alert(_editor_url);
  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;
  var xinha_config = new HTMLArea.Config();
    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);
   //xinha_editors.cat_smdesc.config.width = '600px';
  // xinha_editors.cat_smdesc.config.height = '400px';
   xinha_editors.news_desc.config.width = '500px';
   xinha_editors.news_desc.config.height = '300px';
   //xinha_editors.cat_smdesc.config.statusBar = false;
   xinha_editors.news_desc.config.statusBar = false;
   HTMLArea.startEditors(xinha_editors);
}
window.onload = xinha_init;
</script>
<script language="javascript">
function open_window(cat,img_name)
{
	url = "../images/news/"+cat+"/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function open_window1(img_name)
{
	url = "../images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'news.php?del=1&uid='+uid;
	}
}
</script>
<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">
</head>
<?php
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
			
			
			$delete2=mysql_query("delete from  nile_news  where nile_id='$uid'");
			header("location:news.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		foreach($colors as $chk1)
		{
			
			$delete2=mysql_query("delete from  nile_news  where nile_id='$chk1'");
			
		}
		header("location:news.php?act=view");
		exit;	
			
	}
		

//////////////////////////////end of multiple delete///////////////////////////////////	

///////////////////////////////News letter Send///////////////////////////////////////
if($act == 'send' ){
	
	$selNews = "SELECT * FROM  nile_news  WHERE `nile_id` = '$aid'";
	 	$rsNews  = mysql_query($selNews) or die(mysql_error());
		$resNews = mysql_fetch_assoc($rsNews);
	 	extract($resNews);
		
	
	    $selNewsUsers = "SELECT * FROM `nile_news_users`";


 
	   $rsNewsUsers  = mysql_query($selNewsUsers) or die(mysql_error());
	 $count = mysql_num_rows($rsNewsUsers);
		   /*while($ide=mysql_fetch_array($rsNewsUsers))
		   {*/
		  	
	//////////////////////////////////////////////////
	// 	 Sending Newsletter to registered users		//
	//////////////////////////////////////////////////
	while($resNewsUsers = mysql_fetch_assoc($rsNewsUsers)){
	$sub = $news_title;

	$msg = "<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Welcome to DeeptiPublications</title>
<link href='http://202.63.102.85:82/php/nileriver/style.css' rel='stylesheet' type='text/css' />
<link href=http://202.63.102.85:82/php/nileriver/admin/images/style.css rel=stylesheet type=text/css>
</head>

<body  leftmargin='0' topmargin='0' marginwidth='0' marginheight='0'>

  <table width='91%' border='0' cellpadding='0' cellspacing='0' >
  <tr>
    <td width='33%'><table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>
      <!--<tr>
        	<td width='100%'></td>
      </tr>-->
    </table></td>
    <td width='37%'>&nbsp;</td>
    <td width='30%' align='left' valign='middle' ><div align='center'> <br />
   .</div></td>
  </tr></table>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width='779' border='0' cellpadding='0' cellspacing='0' >
      <tr>
        <td width='6' height='32' align='left'></td>
        <td width='758'><table width='100%' border='0'>
          <tr>
            <td width='12%'>&nbsp;</td>
            <td width='88%'><table width='100%' border='0' >
              
              <tr>
                <td class='search-txt'>&nbsp;</td>
              </tr>
              
              <tr>
                <td class='search-txt'>&nbsp;</td>
              </tr>
              <tr align='left'>
                <td  class=normal align='left'>".stripslashes($news_desc)."</td>
              </tr>
              <tr>
                <td class='search-txt'>&nbsp;</td>
              </tr>
              
              <tr>
                <td class='search-txt'>&nbsp;</td>
              </tr>
              <tr align='left'>
                <td class='normal' align='left'><span class='search-txt'> Thank You,</span></td>
              </tr>
              <tr align='left'>
                <td class='normal' align='left'>The deeptipublications Support Team</td>
              </tr>
			   <tr align='left'>
                <td class='normal' align='left'>http://www.deeptipublications.com</td>
              </tr>
              
            </table></td>
          </tr>
        </table></td>
        <td width='6' align='right'></td>
      </tr>
    </table></td>
  </tr>
  
</table>
</body>

</html>";
	
	
	$msg = stripslashes($msg);
	
	$mail = new PHPMailer();
	//$mail->IsMail();
	$mail->IsSMTP();                                      // set mailer to use SMTP
	$mail->Host = "www.srisolutions.in";  // specify main and backup server
	$mail->SMTPAuth = true;     // turn on SMTP authentication
	$mail->Username = "info@24by7info.net";  // SMTP username
	$mail->Password = "indian"; // SMTP password
	
		$mail->From     = "info@24by7info.net";
		$mail->FromName = "24by7Info";
		$mail->AddAddress($resNewsUsers["email"]);
		$mail->IsHTML(true);                                  // set email format to HTML
		$mail->Subject = $sub;
		$mail->Body = $msg;
		$mail->AltBody = "This is the body in plain text for non-HTML mail clients";
	
		$mail->Send();
		 $mail->Body;
		 
		 
		
  
		 
	
	}
	header("Location:news.php?act=view&count=$count");
		exit;
}

//////////////////////////////End/////////////////////////////////////////////////////

//////////////////////////////////////ADD////////////////////////////////////////////
$ok=$_REQUEST[ok];
if($ok==add)
{
	$selCat = mysql_query("SELECT * FROM  nile_news  WHERE news_title='$news_title'");
	$num=mysql_num_rows($selCat);
	if($num<=0)
	{
	
			$newsdesc=addslashes($news_desc);
			
	
	
		$sql=mysql_query("insert into  nile_news (news_title,news_desc,date_added,last_modified,news_status,news_cat_type) values('$news_title', '$newsdesc',now(),now(),'$news_status','$cat_type')");
		header("location:news.php?act=view");
		exit;
	}
	else
	{
		header("location:news.php?act=new&error=1");
		exit;
	}
	
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{	
extract($_REQUEST);
			
		$sql=mysql_query("select * from  nile_news  where news_title='$news_title' && nile_id != $idno");
		$row=mysql_fetch_array($sql);
		$cc=mysql_num_rows($sql);
		if($cc<=0){	
	//echo $cat_type;exit;
	$updsub=mysql_query("update  nile_news  set news_title='$news_title', news_desc='$news_desc',last_modified=now(),news_status='$news_status',news_cat_type='$cat_type' where nile_id='$idno'");
	header("location:news.php?act=view");
	exit;
	}
	else
	{
		header("location:news.php?act=view&error=1");
		exit;
	}
}
///////////////////paging////////////////////
$PageSize = 10;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from  nile_news ");
	//echo "select * from  nile_news  LIMIT ". $StartRow .",". $PageSize."";exit;
	$sql=mysql_query("select * from  nile_news  LIMIT ". $StartRow .",". $PageSize."");
		
		
		




$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);

?>


<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			 <?php if($act=="view"){?>
	<form name="formx" method="post" enctype="multipart/form-data">
	
<table width="100%">
	
	<tr>
		<td height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">View News </b></td>
	</tr>
	<?php  if($num<=0){?>
		<tr>
			<td height="40" colspan="2" align="center" class="style14">
			<?php 
				header("Location:news.php?act=new");
			?>			</td>
		</tr>
	<?php  } else { 
					
	?>
					
					<tr class="txtblack3" >
					  <td height="10" align="right" class="normal" colspan="10" ><a href="news.php?act=new" class="greentextbold">Add News </a></td>
	  </tr>
					<tr class="txtblack3" >
					  <td height="10" align="center" class="normal" colspan="10" ><span class="style14">
					    <?php 
					  if($error==1)
					  {
					  	echo "News Title already exists";
					  }
					  ?>
					  </span></td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page:<?php echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
	
	                
					 
					  <tr>
	                  <td height="25" align="center" valign="middle" class="greentextbold">
					 <?php if(isset($_GET["count"])){ 
					  if($_GET["count"] == 0){
					  ?> <span class="style14">No user activated yet!</span>
					 <?php }else{
					   ?>
					 <span class="greentextbold"> News Letter Send To <font color="red">
	                   <?php echo $_GET["count"]?>
	                    </font> Members Successfully!.</span><?php
						} }
						?></td>
          </tr>
						
          <tr>
		<td colspan="2">
			<table width=86% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
				<tr class="txtblack3" bgcolor="#FA9032" >
				  <td width="57" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
				  <td width="219" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><span class="tahoma11boldwhite">News Title </span></div></td>
				  <td width="145" bgcolor="#FA9032" class="style12"><div align="center" class="itemstyle"><span class="tahoma11boldwhite">Date Added</span></div></td>
				  <td width="125" class="style12"><div align="center" class="itemstyle"><span class="tahoma11boldwhite">Last Modified </span></div></td>
				  <td width="65" align="center" bgcolor="#FA9032" class="style12"><span class="itemstyle">Status</span></td>
				  <td width="50" align="center" bgcolor="#FA9032" class="style12"><div align="center" class="itemstyle">Send</div></td>
				  <td width="50" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>
					<td width="71" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Delete</b></td>
			  </tr>
<?php  
 while($row=mysql_fetch_array($sql))
{ 
				if($row['news_status'] ==1){
					$href = "news.php?act=send&aid=$row[nile_id]";
					
				}else{
					$href= "javascript:alert('You must activate this newsletter to send.');";
				}
?>
				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">
						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?php echo $row['nile_id']; ?>"> 
   					  <input type="checkbox" name="chk[]"  id="chk" value="<?php  echo $row['nile_id']; ?>" onClick="checkval('chk[]')"></td>
				
					<td height="28" class="normal style12"><div align="center">
					 <?php echo $row[news_title]?>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					<?php  
					list($year1,$month1,$date1)=split('[-]',$row[date_added]);
					echo $month1."/".$date1."/".$year1;
				?>
					  
				    </div></td>
					<td class="normal style12"><div align="center">
					<?php 
					list($year,$month,$date)=split('[-]',$row[last_modified]);
					echo $month."/".$date."/".$year;
				?>
                       
                    </div></td>
					<td align="center" class="normal style12"><?php  if($row['news_status'] ==1){ echo "Approved";}else{ echo "Rejected";}?></td>
					<td align="center" class="normal style12"><a href="<?php echo $href?>"><img src="images/email.gif" width="16" height="16" border="0" /></a></td>
					<td height="28" class="normal style12"><div align="center">
					  <a href="news.php?act=edit&aid=<?php echo $row[nile_id]?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					   <a href="javascript:delete1(<?php echo $row['nile_id']?>)"><img src="images/delete.png" width="18" height="18" border="0"></a>
				    </div></td>
			  </tr><?php
					}
					?>
		  </table>	  </td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><img src="images/delete1.gif" onClick="javascript:document.formx.action='news.php?ok=alldel';document.formx.submit();"><!--<input name="delete" type="button" class="greentextbold" onClick="javascript:document.formx.action='news.php?ok=alldel';document.formx.submit();" value="Delete">--></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & brvious Link is necessary
        if($CounterStart != 1){
            $brvStart = $CounterStart - 1;
            print "<a href=news.php?PageNo=1&act=view>First </a>: ";
            print "<a href=news.php?PageNo=$brvStart&act=view>brvious </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=news.php?PageNo=$c&act=view>$c</a> ";
                }else{
                    echo "<a href=news.php?PageNo=$c&act=view>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=news.php?PageNo=$c&act=view>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=news.php?PageNo=$NextPage&act=view>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=news.php?PageNo=$MaxPage&act=view>Last</a>";
        }?></td>
	  </tr>
	</table>
	</form>
	
	<?php 
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					 <?php 
				  		
					  if($act=='new' || $act=='edit') {
					   if($act == 'edit'){
					$chn=mysql_query("select * from  nile_news  where nile_id='$aid'");
					$row=mysql_fetch_array($chn);
					extract($row);
					}
					  ?>
					  <form name="formx1" method="post" enctype="multipart/form-data">
						<input type="hidden" name='idno' value="<?php echo $aid?>">
						<input type="hidden" name='oldname' value="<?php echo $catname?>">
						<input type="hidden" name='img' value="<?php echo $image?>">
					  <TABLE cellSpacing=0 cellPadding=0 width=100% align=center border="0">
                        <tr>
                          <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
                            <?php
							if($aid){
							?>
                            Edit News Details
 <?php }else {?>
                            Add News Details
 <?php }?>
                          </b></td>
                        </tr>
						<tr>
						<td colspan="3" align="center" class="style14">
						<?php
						if($error==1)
						{
							echo "Category already Exists";
						}
						?>						</td>
						</tr>
                        <tr>
                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="news.php?act=view" class="greentextbold"><b>View News </b></a>&nbsp;</td>
                        </tr>
                        <TR>
                          <TD width="294" height="30" align="right" class="itemstyle">News Title </TD>
                          <TD width="39" align="center">:</TD>
                          <TD width="350"><input name="news_title" type="text" id="news_title" value="<?php echo $news_title?>" size="25" /></TD>
                        </TR>
						<?php 
						// Code to retrieve categories////////

					$sql_category=mysql_query("select * from nile_category ");?>
						<TR>
                          <TD width="294" height="30" align="right" class="itemstyle">Category Type </TD>
                          <TD width="39" align="center">:</TD>
                          <TD width="350"><select name="cat_type">
						  <option value="0">Please Select Category</option>
						 <?php foreach($new_array as $value)
						  					{ 
						  					?>
						  <option value="<?php echo  $value?>"<?php if(isset($_GET['aid'])){ if($news_cat_type==$value){?> selected="selected"<?php } } ?>><?php echo $value?></option>
						 <?php } ?>
						  </select>
						  
						  
						  </TD>
                        </TR>
						<TR><TD>&nbsp;	</TD></TR>
                        <TR>
                          <TD height="30" align="right" class="itemstyle"> Description </TD>
                          <TD align="center">:</TD>
                          <TD>
						  <!--<textarea id="news_desc" name="news_desc" rows="5" cols="25"  style="width:173px"><?php echo stripslashes($news_desc)?></textarea>-->			
						
						  <?php
					$oFCKeditor = new FCKeditor('news_desc') ; 
					$oFCKeditor->BasePath = 'FCKeditor/';
					$oFCKeditor->Value =$news_desc;
					$oFCKeditor->Width  = '550' ;
					$oFCKeditor->Height = '400' ;
					$oFCKeditor->Create() ;
			 ?>
						  
						  
						  			  </TD>
                        </TR>
                       <?php if($act == 'edit'){?>
						<?php } ?>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Approve News </TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="news_status" type="radio" value="1"<?php if( isset($news_status) && $news_status == 1 ){ echo "checked";}?> />
                            Yes
                            <input name="news_status" type="radio" value="0"<?php if( isset($news_status) && $news_status == 0 ){ echo "checked";}else if($act == 'new'){ echo "checked";}?> />
                          No</td>
                        </TR>
                        <TR>
                          <TD height="60" colspan="3" align="center"><?php
			if($aid){
			?>
                             <img src="images/update.gif" onClick="javascript:return news1();"> <!--<input name="submit" type="submit" class="normal" onClick="javascript:return news1();" value='Update'>-->
                              <?php
		} else {
		?>
                <img src="images/addnews.gif" onClick="javascript:return news();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return news();" value='Add News'>-->
                           <?php } ?>
                            &nbsp;
                           <img src="images/cancel.gif" onClick="javascript:document.formx1.action='news.php?act=view';document.formx1.submit();"> <!--<input name="submit1" type="submit" class="normal" onClick="javascript:document.formx1.action='news.php?act=view';document.formx1.submit();" value="Cancel">-->                          </TD>
                        </TR>
                        <TR>
                          <TD height="50" colspan="3">&nbsp;</TD>
                        </TR>
                      </TABLE>
					  <?php  
					  }
					  ?>
					  </form>
					 <!-- END ADD AND EDIT -->
					  
					  </td>
	  </tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			