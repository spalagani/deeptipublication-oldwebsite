<?php 
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>
<script language="javascript">
var OpenSubX = (screen.width/2)-5;
var OpenSubY = (screen.height/2)-100;
var pos = "left="+OpenSubX+",top="+OpenSubY;

function openSub(x){
		
		openSub1Window = window.open("../template.php?id="+x ,"not","width=220,height=150,"+pos);
		
}
function openSubC(x){
		//alert(x);
		openSub1Window = window.open("../color.php?id="+x ,"not","width=300,height=320,"+pos);
		
}
</script>

</head>
<?php 
	extract($_REQUEST);
	
	//////////////////////////////////////ADD////////////////////////////////////////////
if($ok==add)
{
 echo "insert into nile_admin (fname,lname,username,password,email,date_added,status) values('$fname', '$lname','$username','$password','$email',now(),'1')";
	$sql=mysql_query("insert into nile_admin (fname,lname,username,password,email,date_added,date_modified,status) values('$fname', '$lname','$username','$password','$email',now(),now(),'1')");
	//header("location:admin.php");
	exit;
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{
/*echo $ok;
echo "update nile_user set fname='$fname', lname='$lname', username='$username',  password='$password' , email='$email' where admin_id='$idno'";
	exit;*/
	$sql=mysql_query("update nile_admin set fname='$fname', lname='$lname', username='$username',  password='$password' , email='$email',date_modified=now() where admin_id='$idno'");
	header("location:admin.php");
	exit;
}
$aid=$_REQUEST[aid];
$chn=mysql_query("select * from nile_admin where admin_id='$aid'");
$row=mysql_fetch_array($chn);
?>
<body>
<form name="formx" method="post">
<input type="hidden" name='idno' value="<?php echo $aid?>">
	<TABLE cellSpacing=0 cellPadding=0 width=683 align=center border="0">
		<tr>
			<td height="40" colspan="2" align="right" class="txtnolink">&nbsp;<b class="greentext22bold"><?php 
			if($aid){
			?>Edit Admin Details<?php  }else {?>Add Admin Details<?php  }?></b></td>
			<td width="350" align="right"><a href="admin.php" class="greentextbold"><b>View Users</b></a>&nbsp;</td>
		</tr>
	  <TR>
		  	<TD width="294" height="30" align="right" class="normal"><span class="style14">*</span> First Name</TD>
			<TD width="39" align="center">:</TD>
			<TD><input size=25 name="fname" value="<?php echo $row[fname]?>"></TD>
	  </TR>
	  
	  
	  <TR>
		  	<TD height="30" align="right" class="normal"><span class="style14">*</span> Last Name</TD>
			<TD align="center">:</TD>
			<TD><input size=25 name="lname" value="<?php echo $row[lname]?>"></TD>
	  </TR>
	   <TR>
		  	<TD height="30" align="right" class="normal"><span class="style14">*</span> Username </TD>
			<TD align="center">:</TD>
			<TD><input size=25 name="username" value="<?php echo $row[username]?>"></TD>
	  </TR>
	   <TR>
         <TD height="30" align="right" class="normal"><span class="style14">*</span> Password</TD>
	     <TD align="center">:</TD>
	     <TD><input size=25 name="password" value="<?php echo $row[password]?>"></TD>
      </TR>
	   <TR>
         <TD height="30" align="right" class="normal"><span class="style14">*</span> Email</TD>
	     <TD align="center">:</TD>
	     <TD><input size=25 name="email" value="<?php echo $row[email]?>"></TD>
      </TR>
	  
	  
	  <TR>
	  	<TD height="60" colspan="3" align="center">
		<?php 
			if($aid){
			?>
			<img src="images/update.gif" onClick="javascript:document.formx.action='admin_edit.php?ok=edit';document.formx.submit();return admin1();">
  	   <?php 
		} else {
		?><img src="images/addadmin.gif" onClick="javascript:document.formx.action='admin_edit.php?ok=add';document.formx.submit();return admin();"><?php  }?> &nbsp;
		<img src="images/cancel.gif" onClick="javascript:document.formx.action='admin.php';document.formx.submit();"></TD>
	</TR>
       <TR>
		  	<TD height="50" colspan="3">&nbsp;</TD>
	</TR>
</TABLE>			
	</td>
		</tr>
  </TABLE>
</form>
 </BODY>
 </HTML>
