<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
include("FCKeditor/fckeditor.php");

?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>


</head>
<?
if((isset($_REQUEST['headerimages']))&($_REQUEST['headerimages']==1))
{

	$description=$_REQUEST['description'];

/// Deleting files in a folder from mingwin//////
if(($_FILES["image1"]["tmp_name"]<>'')||($_FILES["image2"]["tmp_name"]<>'')||($_FILES["image3"]["tmp_name"]<>'')){
$dirname1="mingwin";
 $dirname2="mingwin_actual"; 
function full_rmdir($dirname){
        if ($dirHandle = opendir($dirname)){
            $old_cwd = getcwd();
            chdir($dirname);

            while ($file = readdir($dirHandle)){
			
                if ($file == '.' || $file == '..') continue;

                if (is_dir($file)){
                    if (!full_rmdir($file)) return false;
                }else{
                    if (!unlink($file)) return false;
                }
            }

            closedir($dirHandle);
            chdir($old_cwd);
          

            return true;
        }else{
            return false;
        }
    }
	$s=full_rmdir($dirname1);
	
	//////// Deleting images from mingwin_actual//////////
	
	/// Deleting files in a folder from mingwin//////
	
	$d=full_rmdir($dirname2);
	//End of the code/////////////

			

		if(is_uploaded_file($_FILES["image1"]["tmp_name"])){
			
				move_uploaded_file($_FILES["image1"]["tmp_name"], "mingwin_actual/" . $_FILES["image1"]["name"]);
				
				$Attachments=$_FILES["image1"]["name"];
				
			}
			
			if(is_uploaded_file($_FILES["image2"]["tmp_name"])){
			
				move_uploaded_file($_FILES["image2"]["tmp_name"], "mingwin_actual/" . $_FILES["image2"]["name"]);
				
				$Attachments1=$_FILES["image2"]["name"];
				
			}
			
			if(is_uploaded_file($_FILES["image3"]["tmp_name"])){
			
				move_uploaded_file($_FILES["image3"]["tmp_name"], "mingwin_actual/" . $_FILES["image3"]["name"]);
				
				$Attachments2=$_FILES["image3"]["name"];
				
			}?>
			
			<?
			/************************************Resizing the image 660x300****************/
			if($Attachments<>'')
			{
			$path="mingwin_actual";
			$filetype=$_FILES['image1']['type'];
			$bgim_file_name = $path."/".$Attachments; 
			
			$bgimage_attribs = getimagesize($bgim_file_name);
			
			
			if($filetype=='image/gif')	{
				$bgim_old = imagecreatefromgif($bgim_file_name); 
			}	
			else	{
				 $bgim_old = imagecreatefromjpeg($bgim_file_name);
			}
						
			$bgth_max_width = 535; //for Album image
			$bgth_max_height = 225;
			$bgratio = ($bgwidth > $bgheight) ? $bgth_max_width/$bgimage_attribs[0] : $bgth_max_height/$bgimage_attribs[1];
		
			$bgth_width = 535;//$image_attribs[0] * $ratio; 
			$bgth_height = 225;//$image_attribs[1] * $ratio;
		
			$bgim_new = imagecreatetruecolor($bgth_width,$bgth_height); 
			imageantialias($bgim_new,true); 
			 $bgth_file_name = "mingwin/$Attachments";
						 
			imagecopyresampled($bgim_new,$bgim_old,0,0,0,0,$bgth_width,$bgth_height, $bgimage_attribs[0], $bgimage_attribs[1]);
		
			if($filetype=='image/gif')	{									
				imagegif($bgim_new,$bgth_file_name,100); 
			}	else	{
				imagejpeg($bgim_new,$bgth_file_name,100);
			}}
			////////////////////////////////////////end resize/////////////////////////////////////
			
			
			
			?>
			
			<?
			/************************************Resizing the image 660x300****************/
			if($Attachments1<>'')
			{
			$path="mingwin_actual";
			$filetype=$_FILES['image2']['type'];
			$bgim_file_name = $path."/".$Attachments1; 
			
			$bgimage_attribs = getimagesize($bgim_file_name);
			
			
			if($filetype=='image/gif')	{
				$bgim_old = imagecreatefromgif($bgim_file_name); 
			}	
			else	{
				 $bgim_old = imagecreatefromjpeg($bgim_file_name);
			}
						
			$bgth_max_width = 535; //for Album image
			$bgth_max_height = 225;
			$bgratio = ($bgwidth > $bgheight) ? $bgth_max_width/$bgimage_attribs[0] : $bgth_max_height/$bgimage_attribs[1];
		
			$bgth_width = 535;//$image_attribs[0] * $ratio; 
			$bgth_height = 225;//$image_attribs[1] * $ratio;
		
			$bgim_new = imagecreatetruecolor($bgth_width,$bgth_height); 
			imageantialias($bgim_new,true); 
			 $bgth_file_name = "mingwin/$Attachments1";
						 
			imagecopyresampled($bgim_new,$bgim_old,0,0,0,0,$bgth_width,$bgth_height, $bgimage_attribs[0], $bgimage_attribs[1]);
		
			if($filetype=='image/gif')	{									
				imagegif($bgim_new,$bgth_file_name,100); 
			}	else	{
				imagejpeg($bgim_new,$bgth_file_name,100);
			}}
			////////////////////////////////////////end resize/////////////////////////////////////
			
			
			
			?>
			
			
			<?
			/************************************Resizing the image 660x300****************/
			if($Attachments2<>'')
			{
			$path="mingwin_actual";
			$filetype=$_FILES['image3']['type'];
			$bgim_file_name = $path."/".$Attachments2; 
			
			$bgimage_attribs = getimagesize($bgim_file_name);
			
			
			if($filetype=='image/gif')	{
				$bgim_old = imagecreatefromgif($bgim_file_name); 
			}	
			else	{
				 $bgim_old = imagecreatefromjpeg($bgim_file_name);
			}
						
			$bgth_max_width = 535; //for Album image
			$bgth_max_height = 225;
			$bgratio = ($bgwidth > $bgheight) ? $bgth_max_width/$bgimage_attribs[0] : $bgth_max_height/$bgimage_attribs[1];
		
			$bgth_width = 535;//$image_attribs[0] * $ratio; 
			$bgth_height = 225;//$image_attribs[1] * $ratio;
		
			$bgim_new = imagecreatetruecolor($bgth_width,$bgth_height); 
			imageantialias($bgim_new,true); 
			 $bgth_file_name = "mingwin/$Attachments2";
						 
			imagecopyresampled($bgim_new,$bgim_old,0,0,0,0,$bgth_width,$bgth_height, $bgimage_attribs[0], $bgimage_attribs[1]);
		
			if($filetype=='image/gif')	{									
				imagegif($bgim_new,$bgth_file_name,100); 
			}	else	{
				imagejpeg($bgim_new,$bgth_file_name,100);
			}}
			////////////////////////////////////////end resize/////////////////////////////////////
			
			
			/* ********************************* for deleting flash files */
			
			
			$f1="flash/".$_REQUEST['filename'];
			
			unlink($f1);
		
			
		/*	***********************************/
		
/********************************************************************************
* @ File: slideshow.php
* @ Original date: October 2003 @ www16.brinkster.com/gazb/ming/
* @ Version: 2.0
* @ Summary:  grab jpgs from folders and create a swf slideshow
* @ Updated:  small improvements and summary text
* @ Copyright (c) 2003-2007, www.gazbming.com - all rights reserved.
* @ Author: gazb.ming [[@]] gmail.com - www.gazbming.com 
* @ Released under GNU Lesser General Public License - http://www.gnu.org/licenses/lgpl.html
********************************************************************************/

// just put the directories with the jpgs here and compile
$pathtojpgs= array();
 $pathtojpgs[0]= "mingwin/";
//$pathtojpgs[1]= "mingwin/";
//$pathtojpgs[2]= "mingwin/";
//$pathtojpgs[3]= "mingwin/";
//$pathtojpgs[4]= "mingwin/";

// some typical movie variables
$char ="header";
Ming_setScale(20.0000000);
ming_useswfversion(6);
ming_keypress("a");
$movie=new SWFMovie();
//$movie->setBackground(rand(0,0xFF),rand(0,0xFF),rand(0,0xFF));
$movie->setRate(25); 
$movie->setDimension(535,225);

//// easing equation converted to php from Actionscript @ 
// http://www.robertpenner.com/easing_equations.as
// use of which are subject to the license @
// http://www.robertpenner.com/easing_terms_of_use.html
function easeInQuad ($t, $b, $c, $d) {
$t/=$d;
	return $c*$t*$t + $b;
};
function easeOutQuad ($t, $b, $c, $d) {
$t/=$d;
	return -$c *($t)*($t-2) + $b;
};

// basic actionscript control of playback using mouse
$strAction="
if(!init){
	init=true;
	stopped=false;
	controls = {
		onMouseDown: function () {
			if(!stopped){
				stop();
				stopped=true;
			}else{
				play();
				stopped=false;
			}
		}
	};
	Mouse.addListener(controls);
}
";
$movie->add(new SWFAction($strAction));

// grab the jpgs
$f = array();
for($i=0;$i<count($pathtojpgs);$i++){
	$f[$i] = array();
	if ($handle = opendir($pathtojpgs[$i])) {
		while (false !== ($file = readdir($handle))) { 
			$tmp = explode(".",$file);
			if($tmp[1]=="jpg"){
				array_push ($f[$i],$pathtojpgs[$i] . $file);
			}
			
			if($tmp[1]=="gif"){
				array_push ($f[$i],$pathtojpgs[$i] . $file);
			}
		}
	}
}
closedir($handle);




///////////////slideshow patch start//////////////////////////////
// sort the jpgs into 'natural' order using natsort		//
// (eg 1.jpg,a.jpg,b1.jpg,b2.jpg,b10.jpg,b12.jpg,b100.jpg)	//
// see www.php.net Array docs for alts to natsort		//
for($i=0;$i<count($f);$i++){					//
// echo "original order\n";					//
// print_r($f[0]);						//
								//
natsort($f[$i]); 	// sort that array			//
$tmp=implode(",",$f[$i]); // ugly...				//
$f[$i]=explode(",",$tmp); // but it works			//
								//
// echo "new order\n";						//
// print_r($f[0]);						//
}								//
///////////////slideshow patch end////////////////////////////////



// add the jpgs to the movie with basic fade in/out
$movie->nextFrame();
for($i=0;$i<count($f);$i++){
	for($k=0;$k<count($f[$i]);$k++){
		$img = new SWFBitmap(fopen($f[$i][$k],"rb"));
		$pic=$movie->add($img); 
		//$pic->moveTo( (275-$img->getwidth()/2),(50-$img->getheight()/2));
		$transition=20;
$cnt=1; $startpos=0; $offset=1; $duration=$transition;
while($cnt<=$duration){
$inc=easeInQuad ($cnt++, $startpos, $offset, $duration);
			$pic->multColor(1,1,1,$inc);
			$movie->nextFrame();
		}
		for($j=1;$j<=$transition*2;$j++){
			$movie->nextFrame();
		}
$cnt=1; $startpos=1; $offset=-1; $duration=$transition;
while($cnt<=$duration){
$inc=easeOutQuad ($cnt++, $startpos, $offset, $duration);
			$pic->multColor(1,1,1,$inc);
			$movie->nextFrame();
		}
		$movie->remove($pic);
	}
}
$movie->nextFrame();


// save swf with same name as filename
 $swfname = basename(__FILE__,".php").rand().".swf";
$movie->save("flash/$swfname",9);
}
else
{
 $swfname = $_REQUEST['filename'];

}

$swf_insert=mysql_query("update nile_header_banner set swf_filename='$swfname',description='$description' where  header_banner_id ='1'") or die(mysql_error());

header("location:home_banner.php");
}

?>

 <? 
					  		$banner_sql="select * from nile_header_banner where header_banner_id='1'";
							$banner_execute=mysql_query($banner_sql);
							$swfname=mysql_fetch_array($banner_execute);
					  
					  
					  ?>
					  
<body>
<form name="formx" method="post"  enctype="multipart/form-data">
<input type="hidden" name="headerimages" value="1">
<input type="hidden" name='idno' value="<?=$aid?>">
	<TABLE cellSpacing=0 cellPadding=0 width=683 align=center border="0">
		<tr>
			<td  height="40" colspan="2" align="left" class="txtnolink" >&nbsp;<b class="greentext22bold">
			Banner Details</b></td>
			<td width="80" align="right">&nbsp;</td>
		</tr>
		
	  <TR>
		  	<td align="left" valign="bottom">
			
			<table width="96%" border="0" align="center" cellpadding="0" cellspacing="0">
  
  <tr>
    <td class="bold_txt">Image1:</td>
    
    <td> <input type="file" size=25 name="image1" ></td>
  </tr>
  <tr><td>&nbsp;</td></tr>
  <tr>
    <td class="bold_txt">Image2:</td>
    <td><input type="file" size=25 name="image2" ></td>
  </tr>
  <tr><td>&nbsp;</td></tr>
  <tr>
    <td class="bold_txt">Image3:</td>
    <td><input type="file" size=25 name="image3" ></td>
  </tr>
  <tr><td>&nbsp;</td></tr>
  
  
  <tr><td>&nbsp;</td></tr>
</table>			</td>

<td valign="top" align="center"><table width="312" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="312" align="center" valign="top"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="312" height="171">
      <param name="movie" value="flash/<?=$swfname['swf_filename'];?>">
      <param name="quality" value="high">
      <embed src="flash/<?=$swfname['swf_filename'];?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="312" height="171"></embed>
    </object></td>
  </tr>
</table>
</td>
	  </TR>
	  <tr>
    <td class="bold_txt" colspan="2"><table><tr><td class="bold_txt"><b>Description</b>:</td>
    <td><?php /*?><textarea name="description" cols="40" rows="15"><?=$swfname['description'];?></textarea><?php */?>
	<?php
					$oFCKeditor = new FCKeditor('description') ; 
					$oFCKeditor->BasePath = 'FCKeditor/';
					$oFCKeditor->Value =$swfname['description'];
					$oFCKeditor->Width  = '550' ;
					$oFCKeditor->Height = '400' ;
					$oFCKeditor->Create() ;
			 ?>	</td>
  </tr></table></td></tr>
	  
	  
	  <TR align="center" valign="middle">
	  	<TD colspan="3">
		
			<input type="hidden" name="filename" value="<?=$swfname['swf_filename'];?>">
			<input type="image" src="images/submit.gif">
  	   
		 
		<img src="images/cancel.gif" onClick="javascript:document.formx.action='home_banner.php';document.formx.submit();"></TD>
	</TR>
       <TR>
		  	<TD height="50" colspan="3">&nbsp;</TD>
	</TR>
</TABLE>			
	</td>
		</tr>
  </TABLE>
</form>
 </BODY>
 </HTML>
