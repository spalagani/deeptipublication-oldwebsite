<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/connection.php');
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>

<script type="text/javascript">
//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')
// And the language we need to use in the editor.
var _editor_lang = "en";
//var _editor_url  = document.location.href.replace(/xinha\/xinha\*/, '')
var _editor_url = "../../cybermix/admin/xinha/";
</script>
<!-- Load up the actual editor core -->
<script type="text/javascript" src="xinha/htmlarea.js"></script>
<script type="text/javascript">
/*var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'
 ];*/
 var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'
];
/************************************************************************
 * Names of the textareas you will be turning into editors
 ************************************************************************/
var xinha_editors =
[
   'subcat_desc1'
];
/************************************************************************
 * Initialisation function
 ************************************************************************/
function xinha_init()
{
  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)
  //var _editor_url  = document.location.href.replace(/xinha\*/, '');
 // alert(_editor_url);
  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;
  var xinha_config = new HTMLArea.Config();
    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);
   //xinha_editors.cat_smdesc.config.width = '600px';
  // xinha_editors.cat_smdesc.config.height = '400px';
   xinha_editors.subcat_desc.config.width = '500px';
   xinha_editors.subcat_desc.config.height = '300px';
   //xinha_editors.cat_smdesc.config.statusBar = false;
   xinha_editors.subcat_desc.config.statusBar = false;
   HTMLArea.startEditors(xinha_editors);
}
window.onload = xinha_init;
</script>
<script language="javascript">
function open_window(video_name)
{
	url = "../videos/"+video_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}

function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'uploadvideo.php?del=1&uid='+uid;
	}
}
	function set(id)
{ 
	if(id == 1)
	{
		 document.getElementById("video").style.display="none";
		 document.getElementById("videosample").style.display="none";
		 document.getElementById("audio").style.display="block";
		 document.getElementById("audiosample").style.display="block";
	}
	else
	{
		document.getElementById("video").style.display="block";
		 document.getElementById("videosample").style.display="block";
	    document.getElementById("audio").style.display="none";
		document.getElementById("audiosample").style.display="none";
	}
}
	
</script>
<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">
</head>
<?
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
			$vdsql=mysql_query("select * from auc_video where status=1");
			$vdfetch=mysql_fetch_array($vdsql);
			@unlink("../videos/".$vdfetch['video']); 
			$delete2=mysql_query("delete from auc_video where auto_id='$uid'");
			header("location:uploadvideo.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		$vdsql=mysql_query("select * from auc_video where status=1");
		$vdfetch=mysql_fetch_array($vdsql);
			
		foreach($colors as $chk1)
		{
			@unlink("../videos/".$vdfetch['video']); 
			$delete2=mysql_query("delete from auc_video where auto_id='$chk1'");
		}
		header("location:uploadvideo.php?act=view");
		exit;	
			
	}
		

//////////////////////////////end of multiple delete///////////////////////////////////	
//////////////////////////////////////ADD////////////////////////////////////////////
if($ok=="add")
{
		$selprod = mysql_query("SELECT * FROM auc_video WHERE name='$name' and status=1");
		$prodnum=mysql_num_rows($selprod);
	if($prodnum<=0)
	{
		$rand=time();
		$ss=mkdir("../videos/",0777);
		$uploaddir="../videos/";
		$filetype=$_FILES[video][type];
		$filename=$_FILES[video][name];
		$realpath=$uploaddir.$filename;
		if(!empty($filetype)) 
		{	 
			if(move_uploaded_file($_FILES['video']['tmp_name'],$realpath )) 
			{
			
			}
		}

		if($name!="")
		{
			$sql=mysql_query("insert into auc_video (name,description,video,status) values('$name','$description','$filename','$status')");
		}
		
		header("location:uploadvideo.php?act=view");
		exit;
	}
	else
	{
		header("location:uploadvideo.php?act=new&error=1");
		exit;
	}
	
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{
		$rand=time();
		$ss=mkdir("../videos/",0777);
		$uploaddir="../videos/";
		$filetype=$_FILES[video][type];
		$filename=$_FILES[video][name];
		$realpath=$uploaddir.$filename;
		if(!empty($filetype)) 
		{	 
			@unlink("../videos/".$last_image); 
			if(move_uploaded_file($_FILES['video']['tmp_name'],$realpath )) 
			{
			
			}
		}
		else
		{
			$filename=$last_image;
		}
		

	$sql=mysql_query("update auc_video set name='$name',description='$description', video='$filename' ,status='$status' where auto_id='$idno'");
	
	header("location:uploadvideo.php?act=view");
	exit;
}



///////////////////paging////////////////////
$PageSize = 10;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from auc_video");
	$sql=mysql_query("select * from auc_video LIMIT ". $StartRow .",". $PageSize."");


$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);

?>


<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			  <? if($act=="view"){?>
	<form name="formx" method="post" enctype="multipart/form-data">
	<input type="hidden" name="MAX_FILE_SIZE" value="10485766">
	<input type="hidden" name="POST_MAX_SIZE" value="10485766">
	<input type="hidden" name="MAX_EXECUTION_TIME" value="2400">
<table width="100%">
	
	<tr>
		<td height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">View Videos </b></td>
	</tr>
	<? if($num<=0){?>
		<tr>
			<td height="40" colspan="2" align="center" class="style14">
			<?
				header("Location:uploadvideo.php?act=new");
			?>
			</td>
		</tr>
	<? } else { 
	
	
	?>
					
					<!--<tr class="txtblack3" >
					  <td height="10" align="right" class="normal" colspan="10" ><a href="uploadvideo.php?act=new" class="greentextbold">Add Video </a></td>
	  </tr> -->
					<tr class="txtblack3" >
					  <td height="10" align="right" class="normal" colspan="10" >&nbsp;</td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <? echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
	
	<tr>
		<td colspan="2">
			<table width=56% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
				<tr class="txtblack3" bgcolor="#E5EED5" >
				  <td width="93" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
				  <td width="439" bgcolor="#E5EED5" class="style12"><div align="center" class="itemstyle"><b>Video Name </b></div></td>
				  <td width="123" align="center" bgcolor="#E5EED5" class="style12"><b class="itemstyle">Edit</b></td>
					<td width="173" align="center" bgcolor="#E5EED5" class="style12"><b class="itemstyle">Delete</b></td>
			  </tr>
<? 
 while($row=mysql_fetch_array($sql))
{ 
	$cat=mysql_query("select * from auc_video where status=1");
	$res=mysql_fetch_array($cat);
?>
				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">
						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?=$row['auto_id']; ?>"> 
   					  <input type="checkbox" name="chk[]"  id="chk" value="<? echo $row['auto_id']; ?>" onClick="checkval('chk[]')"></td>
				
					<td height="28" class="normal style12"><div align="center">
					  <?=$row['name']?>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					  <a href="uploadvideo.php?act=edit&aid=<?=$row[auto_id]?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					   <a href="javascript:delete1(<?=$row['auto_id']?>)"><img src="images/delete.png" width="18" height="18" border="0"></a>
				    </div></td>
			  </tr><?
					}
					?>
		  </table>	  </td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><input name="delete" type="button" class="greentextbold" onClick="javascript:document.formx.action='uploadvideo.php?ok=alldel';document.formx.submit();" value="Delete"></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & Previous Link is necessary
        if($CounterStart != 1){
            $PrevStart = $CounterStart - 1;
            print "<a href=uploadvideo.php?PageNo=1&act=view class='greenlink'>First </a>: ";
            print "<a href=uploadvideo.php?PageNo=$PrevStart&act=view class='greenlink'>Previous </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=uploadvideo.php?PageNo=$c&act=view class='greenlink'>$c</a> ";
                }else{
                    echo "<a href=uploadvideo.php?PageNo=$c&act=view class='greenlink'>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=uploadvideo.php?PageNo=$c&act=view class='greenlink'>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=uploadvideo.php?PageNo=$NextPage&act=view class='greenlink'>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=uploadvideo.php?PageNo=$MaxPage&act=view class='greenlink'>Last</a>";
        }?></td>
	  </tr>
	
	</table></form>
	
	<?
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					  <? 
				  		
					  if($act=='new' || $act=='edit') {
					   if($act == 'edit'){
					$chn=mysql_query("select * from auc_video where auto_id='$aid'");
					$row=getSqlFetch($chn);
					extract($row);
					}
					  ?>
					  <form name="formx1" method="post" enctype="multipart/form-data">
						<input type="hidden" name='idno' value="<?=$aid?>">
					  <TABLE cellSpacing=0 cellPadding=0 width=100% align=center border="0">
                        <tr>
                          <td height="26" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
                            <?
							if($aid){
							?>
                            Edit Video Details
  <? }else {?>
                            Add Video Details
  <? }?>
                          </b></td>
                        </tr>
						<tr>
						<td colspan="3" align="center" class="style14">
						<?
						if($error==1)
						{
							echo "Video already Exists";
						}
						?>						</td>
						</tr>
                        <tr>
                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="uploadvideo.php?act=view" class="greentextbold"> View Videos </a> &nbsp;</td>
                        </tr>
						
						<TR>
						  <TD width="294" height="30" align="right" class="itemstyle">Video  Name </TD>
						  <TD width="39" align="center">:</TD>
						  <TD width="350"><input name="name" class="normal" id="name" value="<?=$name?>" size=25></TD>
					    </TR>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Video  </TD>
                          <TD align="center">:</TD>
                          <TD><input name="video" type="file" class="normal" id="video">
                            <span class="itemstyle">(Upload Video Only)</span></TD>
                        </TR>
                        <? if($act == 'edit'){?>
						<TR>
						  <TD height="30" align="right" class="itemstyle">&nbsp;</TD>
						  <TD align="center">&nbsp;</TD>
						  <td align="left"><?=$video?>
                            <input type="hidden" name="last_image" value="<?=$video?>">
&nbsp;<a href="javascript:open_window('<?=$video?>')" class="greenlink">View</a></td>
					    </TR><? }?>
						 <? if($act == 'edit'){?>
						<? }?>
                        <? if($act == 'edit'){?><? }?>
						
							<? if($act == 'edit'){?>
						<? }?>
						<? if($act == 'edit'){?>
                        <? }?>
						<?
						//echo $catid;
						if($catid!=5 && $cat_id!=5)
						{
						?>
						<?
						}
						?>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Status</TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="status" type="radio" value="1" checked />
                            Yes
                            <input name="status" type="radio" value="0" <? if( isset($status) && $status == 0 ){ echo "checked";}?>>
                            No</td>
                        </TR>
                        <TR>
                          <TD height="60" colspan="3" align="center"><?
			if($aid){
			?>
                              <input name="submit" type="submit" class="normal" onClick="javascript:return video1();" value='Update'>
                              <?
		} else {
		?>
                <input name="submit1" type="submit" class="normal" onClick="javascript:return videos();" value='Submit'>
                            <? }?>
                            &nbsp;
                            <input name="submit2" type="submit" class="normal" onClick="javascript:document.formx1.action='uploadvideo.php?act=view';document.formx1.submit();" value="Cancel">                          </TD>
                        </TR>
                        <TR>
                          <TD height="50" colspan="3">&nbsp;</TD>
                        </TR>
                      </TABLE>
					  <?
					  }
					  ?>
					  </form>
					 <!-- END ADD AND EDIT -->
					  
					  </td>
	  </tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			