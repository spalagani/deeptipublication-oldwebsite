<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
include "../includes/class.phpmailer.php";
include "../includes/class.smtp.php";
include("FCKeditor/fckeditor.php");
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>

<script type="text/javascript">
//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')
// And the language we need to use in the editor.
var _editor_lang = "en";
//var _editor_url  = "/brwrap/admin/xinha/";
var _editor_url = "xinha/";
</script>
<!-- Load up the actual editor core -->
<script type="text/javascript" src="xinha/htmlarea.js"></script>
<script type="text/javascript">
/*var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'
 ];*/
 var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'
];
/************************************************************************
 * Names of the textareas you will be turning into editors
 ************************************************************************/
var xinha_editors =
[
   'news_desc'
];
/************************************************************************
 * Initialisation function
 ************************************************************************/
function xinha_init()
{
  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)
  //var _editor_url  = document.location.href.replace(/xinha\*/, '');
 // alert(_editor_url);
  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;
  var xinha_config = new HTMLArea.Config();
    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);
   //xinha_editors.cat_smdesc.config.width = '600px';
  // xinha_editors.cat_smdesc.config.height = '400px';
   xinha_editors.news_desc.config.width = '500px';
   xinha_editors.news_desc.config.height = '300px';
   //xinha_editors.cat_smdesc.config.statusBar = false;
   xinha_editors.news_desc.config.statusBar = false;
   HTMLArea.startEditors(xinha_editors);
}
window.onload = xinha_init;
</script>
<script language="javascript">
function open_window(cat,img_name)
{
	url = "../images/news/"+cat+"/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function open_window1(img_name)
{
	url = "../images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'blog.php?del=1&uid='+uid;
	}
}
</script>
<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">
</head>
<?
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
			
			
			$delete2=mysql_query("delete from   nile_blog_comment  where blog_id='$uid'");
			header("location:blog.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		foreach($colors as $chk1)
		{
			
			$delete2=mysql_query("delete from   nile_blog_comment  where blog_id='$chk1'");
			
		}
		header("location:blog.php?act=view");
		exit;	
			
	}
		

//////////////////////////////end of multiple delete///////////////////////////////////	

//////////////////////////////////////ADD////////////////////////////////////////////
$ok=$_REQUEST[ok];
if($ok==add)
{
	$selCat = mysql_query("SELECT * FROM   nile_blog_comment  WHERE comment_title='$comment_title'");
	$num=mysql_num_rows($selCat);
	if($num<=0)
	{
	
			$blogdesc=addslashes($blog_comment);
	
			$adminid="a1".$_SESSION['userid'];
			
	
		 $sql=mysql_query("insert into  nile_blog_comment (blog_id,user_id,comment_title,comment,comment_date,status) values('$ino','admin','$comment_title','$blogdesc',now(),'1')");
		header("location:blog_comment.php?act=view");
		exit;
	}
	else
	{
		header("location:blog_comment.php?act=new&error=1");
		exit;
	}
	
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{	
extract($_REQUEST);
			
		$sql=mysql_query("select * from   nile_blog_comment  where blog_title='$blog_title' && blog_id != $idno");
		$row=mysql_fetch_array($sql);
		$cc=mysql_num_rows($sql);
		if($cc<=0){	
		$blogdesc=addslashes($blog_comment);
	
	$updsub=mysql_query("update   nile_blog_comment  set blog_id='$blogid',user_id='admin',comment_title='$comment_title',comment='$blogdesc',comment_date=now(),status='$status' where comment_id ='$idno'");
	header("location:blog.php?act=view");
	exit;
	}
	else
	{
		header("location:blog.php?act=view&error=1");
		exit;
	}
}
///////////////////paging////////////////////
$PageSize = 10;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from   nile_blog_comment where blog_id='$_REQUEST[blogid]'");
	//echo "select * from   nile_blog_comment  LIMIT ". $StartRow .",". $PageSize."";exit;
	$sql=mysql_query("select * from   nile_blog_comment where blog_id='$_REQUEST[blogid]' LIMIT ". $StartRow .",". $PageSize."");
		
		
		




$RecordCount = mysql_num_rows($TRecord);

$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);

?>


<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			  <? if($act=="view"){?>
	<form name="formx" method="post" enctype="multipart/form-data">
	
<table width="100%">
	
	<tr>
		<td height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">View Comments </b></td>
	</tr>
	<? if($num<=0){?>
		<tr>
			<td height="40" colspan="2" align="center" class="style14">
			<?
				header("Location:blog_comment.php?act=new");
			?>			</td>
		</tr>
	<? } else { 
					
	?>
					
					<tr class="txtblack3" >
					  <td height="10" align="right" class="normal" colspan="10" ><a href="blog_comment.php?act=new&id=<?=$_REQUEST[blogid]?>" class="greentextbold">Add Comment </a></td>
	  </tr>
					<tr class="txtblack3" >
					  <td height="10" align="center" class="normal" colspan="10" ><span class="style14">
					    <?
					  if($error==1)
					  {
					  	echo "Comment Title already exists";
					  }
					  ?>
					  </span></td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <? echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
	
	                
					 
					  <tr>
	                  <td height="25" align="center" valign="middle" class="greentextbold">
					  <? if(isset($_GET["count"])){ 
					  if($_GET["count"] == 0){
					  ?> <span class="style14">No user activated yet!</span>
					  <? }else{
					   ?>
					 <span class="greentextbold"> News Letter Send To <font color="red">
	                    <?=$_GET["count"]?>
	                    </font> Members Successfully!.</span><?
						} }
						?></td>
          </tr>
						
          <tr>
		<td colspan="2">
			<table width=86% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
				<tr class="txtblack3" bgcolor="#FA9032" >
				  <td width="57" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
				  <td width="219" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><span class="tahoma11boldwhite">comment Title </span></div></td>
				  <!--<td width="145" bgcolor="#FA9032" class="style12"><div align="center" class="itemstyle"><span class="tahoma11boldwhite">Category</span></div></td>-->
				  <td width="125" class="style12"><div align="center" class="itemstyle"><span class="tahoma11boldwhite">Added Date </span></div></td>
				  <td width="65" align="center" bgcolor="#FA9032" class="style12"><span class="itemstyle">Status</span></td>
				 
				  <td width="50" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>
					<td width="71" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Delete</b></td>
			  </tr>
<? 
 while($row=mysql_fetch_array($sql))
{ 
				
?>
				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">
						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?=$row['comment_id']; ?>"> 
   					  <input type="checkbox" name="chk[]"  id="chk" value="<? echo $row['comment_id']; ?>" onClick="checkval('chk[]')"></td>
				
					<td height="28" class="normal style12"><div align="center">
					 <a href="blog_comment.php" class="menulink1"> <?=$row[comment_title]?></a>
				    </div></td>
					<?php /*?><td height="28" class="normal style12"><div align="center">
					  <?=$row[blog_category]?>
				    </div></td><?php */?>
					<td class="normal style12"><div align="center">
                        <?=$row[comment_date]?>
                    </div></td>
					<td align="center" class="normal style12"><? if($row['status'] ==1){ echo "Posted";}else{ echo "Not Posted";}?></td>
					
					<td height="28" class="normal style12"><div align="center">
					  <a href="blog_comment.php?act=edit&aid=<?=$row[comment_id]?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					   <a href="javascript:delete1(<?=$row['comment_id']?>)"><img src="images/delete.png" width="18" height="18" border="0"></a>
				    </div></td>
			  </tr><?
					}
					?>
		  </table>	  </td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><img src="images/delete1.gif" onClick="javascript:document.formx.action='blog.php?ok=alldel';document.formx.submit();"><!--<input name="delete" type="button" class="greentextbold" onClick="javascript:document.formx.action='blog.php?ok=alldel';document.formx.submit();" value="Delete">--></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & brvious Link is necessary
        if($CounterStart != 1){
            $brvStart = $CounterStart - 1;
            print "<a href=blog.php?PageNo=1&act=view>First </a>: ";
            print "<a href=blog.php?PageNo=$brvStart&act=view>brvious </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=blog.php?PageNo=$c&act=view>$c</a> ";
                }else{
                    echo "<a href=blog.php?PageNo=$c&act=view>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=blog.php?PageNo=$c&act=view>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=blog.php?PageNo=$NextPage&act=view>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=blog.php?PageNo=$MaxPage&act=view>Last</a>";
        }?></td>
	  </tr>
	</table>
	</form>
	
	<?
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					  <? 
				  		
					  if($act=='new' || $act=='edit') {
					   if($act == 'edit'){
					$chn=mysql_query("select * from   nile_blog_comment  where comment_id='$aid'");
					$row=getSqlFetch($chn);
					
					}
					  ?>
					  <form name="formx1" method="post" enctype="multipart/form-data">
						<input type="hidden" name='idno' value="<?=$aid?>">
						<input type="hidden" name='ino' value="<?=$row['blog_id']?>">
						
					  <TABLE cellSpacing=0 cellPadding=0 width=100% align=center border="0">
                        <tr>
                          <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
                            <?
							if($aid){
							?>
                            Edit Comment Details
  <? }else {?>
                            Add Comment Details
  <? }?>
                          </b></td>
                        </tr>
						<tr>
						<td colspan="3" align="center" class="style14">
						<?
						if($error==1)
						{
							echo "Category already Exists";
						}
						?>						</td>
						</tr>
                        <tr>
                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="blog.php?act=view" class="greentextbold"><b>View Blog </b></a>&nbsp;</td>
                        </tr>
                        <TR>
                          <TD width="294" height="30" align="right" class="itemstyle"> Title </TD>
                          <TD width="39" align="center">:</TD>
                          <TD width="350"><input name="comment_title" type="text" id="comment_title" value="<?=$row['comment_title']?>" size="25" /></TD>
                        </TR>
						 
						

					
						<tr><td>&nbsp;</td></tr>
						
						
                        <TR>
                          <TD height="30" align="right" class="itemstyle"> Description </TD>
                          <TD align="center">:</TD>
                          <TD>
						  <!--<textarea id="news_desc" name="news_desc" rows="5" cols="25"  style="width:173px"><?=stripslashes($news_desc)?></textarea>-->
						  <?php
					$oFCKeditor = new FCKeditor('comment_desc') ; 
					$oFCKeditor->BasePath = 'FCKeditor/';
					$oFCKeditor->Value =$row['comment'];
					$oFCKeditor->Width  = '550' ;
					$oFCKeditor->Height = '400' ;
					$oFCKeditor->Create() ;
			 ?></TD>
                        </TR>
						
						
						<TR>
                          <TD width="294" height="30" align="right" class="itemstyle"> Post to site </TD>
                          <TD width="39" align="center">:</TD>
                          <TD width="350"><input name="status" type="radio" value="1" <? if( isset($row['status']) && $row['status'] == 1 ){ echo "checked";}?> />
                            Yes
                            <input name="status" type="radio" value="0" <? if( isset($row['status']) && $row['status'] == 0 ){ echo "checked";}?>>
                            No</TD>
                        </TR>
						
                        <? if($act == 'edit'){?>
						<? }?>
                        <?php /*?><TR>
                          <TD height="30" align="right" class="itemstyle">Status</TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="blog_status" type="radio" value="1" <? if( isset($blog_status) && $blog_status == 1 ){ echo "checked";}?> />
                            Yes
                            <input name="blog_status" type="radio" value="0" <? if( isset($blog_status) && $blog_status == 0 ){ echo "checked";}else if($act == 'new'){ echo "checked";}?> />
                          No</td>
                        </TR><?php */?>
                        <TR>
                          <TD height="60" colspan="3" align="center"><?
			if($aid){
			?>
                             <img src="images/update.gif" onClick="javascript:return comment_blog1();"> <!--<input name="submit" type="submit" class="normal" onClick="javascript:return news1();" value='Update'>-->
                              <?
		} else {
		?>
                <img src="images/submit.gif" onClick="javascript:return comment_blog();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return news();" value='Add News'>-->
                            <? }?>
                            &nbsp;
                           <img src="images/cancel.gif" onClick="javascript:document.formx1.action='blog.php?act=view';document.formx1.submit();"> <!--<input name="submit1" type="submit" class="normal" onClick="javascript:document.formx1.action='blog.php?act=view';document.formx1.submit();" value="Cancel">-->                          </TD>
                        </TR>
                        <TR>
                          <TD height="50" colspan="3">&nbsp;</TD>
                        </TR>
                      </TABLE>
					  <?
					  }
					  ?>
					  </form>
					 <!-- END ADD AND EDIT -->
					  
					  </td>
	  </tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			