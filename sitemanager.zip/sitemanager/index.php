<?php
ob_start();
session_start();
include('../includes/dbconfig.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $title?></title>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language='javascript'>
<!--
function validate()
{
	var username=document.formx.username.value;
	var password=document.formx.password.value;

	if(username=="")
	{
		alert('Please Enter Username!');
		document.formx.username.focus();
		return false;
	}
	if(password=="")
	{
		alert('Please Enter Password');
		document.formx.password.focus();
		return false;
	}
	else
	{
		document.formx.submit();
	}
}
//-->
</script>
</head>
<body topmargin="0" leftmargin="0" onLoad="javascript:document.formx.username.focus();">
</td>
</tr>
<tr><td><p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td></tr>
<tr><td>
<table width="29%" border="0" align="center" cellpadding="0" cellspacing="0" >
  
  <tr>
    <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="border-width:1px; border-style:solid; border-color:#999999;">
      <tr><td><img src="images/login-header.jpg" width="453" height="70"></td></tr></table></td>
    
  </tr>
  <tr>
    <td>
	<form name="formx" method="post" action='login.php'>

	<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="border-width:1px; border-style:solid; border-color:#999999;">
      <tr>
        <td height="22" colspan="3" align="center" class="normal">Please Enter Your Login Information </td>
        
      </tr>
      <tr>
        <td width="6%" height="34">&nbsp;</td>
        <td width="44%" class="style">Username</td>
        <td width="50%"><input name='username' title="UserName" style="width:160px; height:20px; font-family:verdana; font-size:11px;"></td>
      </tr>
      <tr>
        <td height="34">&nbsp;</td>
        <td class="style">Password</td>
        <td><input type="password" name='password' title="Password" style="width:160px; height:20px; font-family:verdana; font-size:11px;" ></td>
      </tr>
      <tr>
        <td height="35">&nbsp;</td>
        <td>&nbsp;</td>
        <td align="center"><!--<img src="images/login_b.gif" name="submit" onclick='return validate();'>--><input type="image" src="images/login_b.gif" value="Login" name='submit'  title="Login"  onclick='return validate();' ></td>
      </tr>
    </table></form></td>
    
  </tr>
  <tr>
    <td>&nbsp;</td>
    
  </tr>
</table>
</td></tr></table>
</body>
</html>
