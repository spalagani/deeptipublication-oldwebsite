<?php
ob_start();
include('sessionchk.php');
include("../includes/dbconfig.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $admintitle?></title>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='menu.js'></script>
<script language="JavaScript" type="text/javascript">

function getExpDate(days, hours, minutes) {
    var expDate = new Date();
    if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
        expDate.setDate(expDate.getDate() + parseInt(days));
        expDate.setHours(expDate.getHours() + parseInt(hours));
        expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
        return expDate.toGMTString();
    }
}

// utility function called by getCookie()
function getCookieVal(offset) {
    var endstr = document.cookie.indexOf (";", offset);
    if (endstr == -1) {
        endstr = document.cookie.length;
    }
    return unescape(document.cookie.substring(offset, endstr));
}

// primary function to retrieve cookie by name
function getCookie(name) {
    var arg = name + "=";
    var alen = arg.length;
    var clen = document.cookie.length;
    var i = 0;
    while (i < clen) {
        var j = i + alen;
        if (document.cookie.substring(i, j) == arg) {
            return getCookieVal(j);
        }
        i = document.cookie.indexOf(" ", i) + 1;
        if (i == 0) break; 
    }
    return null;
}

// store cookie value with optional details as needed
function setCookie(name, value, expires, path, domain, secure) {
    document.cookie = name + "=" + escape (value) +
        ((expires) ? "; expires=" + expires : "") +
        ((path) ? "; path=" + path : "") +
        ((domain) ? "; domain=" + domain : "") +
        ((secure) ? "; secure" : "");
}

// remove the cookie by setting ancient expiration date
function deleteCookie(name,path,domain) {
    if (getCookie(name)) {
        document.cookie = name + "=" +
            ((path) ? "; path=" + path : "") +
            ((domain) ? "; domain=" + domain : "") +
            "; expires=Thu, 01-Jan-70 00:00:01 GMT";
    }
}


</script>
<script language="JavaScript" type="text/javascript">
var origCols;
function toggleFrame(elem) {
    if (origCols) {
        elem.firstChild.nodeValue = "Hide Menu";
        setCookie("frameHidden", "false", getExpDate(180, 0, 0));
        showFrame();
    } else {
        elem.firstChild.nodeValue = "Show Menu";
        setCookie("frameHidden", "true", getExpDate(180, 0, 0));
        hideFrame();
    }
}
function hideFrame() {
    var frameset = document.getElementById("masterFrameset");
    origCols = frameset.cols;
    frameset.cols = "0, *";
}

function showFrame() {
    document.getElementById("masterFrameset").cols = origCols;
    origCols = null;
}

// set frame visibility based on previous cookie setting
function setFrameVis() {
    if (document.getElementById) {
        if (getCookie("frameHidden") == "true") {
            hideFrame()
        }  
    }
}

</script>
</head>
<frameset rows="60,5%,*" border=0>
  <frame name="banner" scrolling="no" border=0 noresize src='topmenu.php'>
 
  	<frameset id="masterFrameset2" cols="*,794"  noresize onLoad="setFrameVis()">
  	 <frame id="controls" scrolling="no" name="controlsFrame" src="hidemenu.php" />
    <frame src="welcomename.php" />
    </frameset>
     <frameset id="masterFrameset" cols="226,*" onLoad="setFrameVis()">
   <frame frameborder="0" style="valign:top;" name="left" id="controls" src="menu.php" />
    <frame name="main" src="home.php" />
    </frameset>
 </frameset><noframes></noframes>
<script>
	window.status.checked='false';
</script>
</html>