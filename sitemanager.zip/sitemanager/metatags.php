<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>
<script language="javascript">
function open_window(img_name)
{
	url = "images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
var OpenSubX = (screen.width/2)-5;
var OpenSubY = (screen.height/2)-100;
var pos = "left="+OpenSubX+",top="+OpenSubY;

function openSub(x){
		
		openSub1Window = window.open("../template.php?id="+x ,"not","width=220,height=150,"+pos);
		
}
function openSubC(x){
		//alert(x);
		openSub1Window = window.open("../color.php?id="+x ,"not","width=300,height=320,"+pos);
		
}
</script>

</head>
<?
//////Query to update metstags///////////////
if($_REQUEST['update'])
{
	extract($_REQUEST);
	$sql=mysql_query("update tbl_barzz_metatag set  metatag_desc='$metadesc',metatag_keyword='$metakeywords'");
	header("location:home.php");
	exit;
}

$metarows=mysql_query("select * from  tbl_barzz_metatag");
$exec_metarows=mysql_fetch_array($metarows);
?>
<body>
<form name="formx" method="post" >
<input type="hidden" name='mid' value="<?=$exec_metarows['metatag_id']?>">
	<TABLE cellSpacing=0 cellPadding=0 width=683 align=center border="0">
		<tr>
		  <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
	      Edit Settings
	      </b></td>
	  </tr>
	    <TR>
	      <TD width="294" height="30" align="right" class="itemstyle">&nbsp;</TD>
	      <TD width="39" align="center">&nbsp;</TD>
	      <TD width="350">&nbsp;</TD>
      </TR>
	  <TR>
		  	<TD height="30" align="right" class="itemstyle">Meta Description </TD>
			<TD align="center">:</TD>
			<TD><textarea name="metadesc" id="metadesc" cols="20" rows="5"><?=$exec_metarows[metatag_desc]?></textarea></TD>
	  </TR>
	   <TR>
		  	<TD height="30" align="right" class="itemstyle">&nbsp;</TD>
			<TD align="center">:</TD>
			<TD></TD>
	  </TR>
	  
	   <TR>
		  	<TD height="30" align="right" class="itemstyle">Meta Keywords  </TD>
			<TD align="center">:</TD>
		 <TD>
		    <textarea name="metakeywords" id="metakeywords" cols="20" rows="5"><?=$exec_metarows[metatag_keyword]?></textarea></TD>
	  </TR>
       
	  
	  <TR>
	  	<TD height="60" colspan="3" align="center">
		
		<input type="submit" value='Update' name="update">  	   </TD>
	</TR>
       <TR>
		  	<TD height="50" colspan="3">&nbsp;</TD>
	</TR>
</TABLE>			
	</td>
		</tr>
  </TABLE>
</form>
 </BODY>
 </HTML>
