<script language="javascript" src="includes/validation.js"></script>
<script language="javascript">
	function svalidate(j){
		if(j.scategory.value==0 && j.search.value=="" )
		{
			alert("Please select Category or enter text for Search");
			return false;
		}
		else
		{
			return true;
		}
	}
</script>
<table width="779" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="149"><img src="images/header_01.jpg" width="149" height="188" /></td>
        <td width="150"><img src="images/header_02.jpg" width="150" height="188" /></td>
        <td width="111"><img src="images/header_03.jpg" width="111" height="188" /></td>
        <td width="319"><img src="images/header_04.jpg" width="319" height="188" /></td>
        <td width="50"><img src="images/header_05.jpg" width="50" height="188" /></td>
      </tr>
      <tr>
        <td height="31" colspan="5" bgcolor="#01538D"><table width="779" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="8" align="left"></td>
            <td width="308"><table width="307" border="0" align="left" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="76"><table width="76" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td height="31" align="center" valign="middle" background="images/yellow_button.gif"><a href="index.php" class="toplink">Home</a></td>
                      </tr>
                  </table></td>
                  <td width="1"></td>
                  <td width="76"><table width="76" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td height="31" align="center" valign="middle" background="images/yellow_button.gif"><a href="buy.php" class="toplink">Buy</a></td>
                      </tr>
                  </table></td>
                  <td width="1"></td>
                  <td width="76"><table width="76" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td height="31" align="center" valign="middle" background="images/yellow_button.gif"><a href="sell.php" class="toplink">Sell</a></td>
                      </tr>
                  </table></td>
                  <td width="1"></td>
                  <td width="76" height="31" align="left"><table width="76" border="0" align="right" cellpadding="0" cellspacing="0">
                      <tr align="left">
                        <td height="31" align="center" valign="middle" background="images/yellow_button.gif"><a href="#" class="toplink">My Fool </a></td>
                      </tr>
                  </table></td>
                </tr>
            </table></td>
            <td width="105" align="left"><table width="76" border="0" align="left" cellpadding="0" cellspacing="0">
                <tr align="left">
                  <td height="31" align="center" valign="middle" background="images/yellow_button.gif"><a href="help.php" class="toplink">Help</a></td>
                </tr>
            </table></td>
            <td width="358" height="31" align="right" valign="top" background="images/header_down_img2.jpg"><table width="358" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="127" height="31" align="right" class="no-fee-txt">&nbsp;</td>
                  <td width="231" align="left" class="no-fee-txt">No Fees, No Hassles, No Kidding! </td>
                </tr>
            </table></td>
          </tr>
          <form name="sform" action="allitems.php?ss=1" method="post" onsubmit="return svalidate(this);"><tr>
            <td height="31" colspan="4" align="left">
			<table width="779" border="0" cellpadding="0" cellspacing="0" bgcolor="#01538D">
                <tr>
                  <td width="6" height="32" align="left"></td>
                  <td width="758"><table width="767" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="14" height="32"><img src="images/blue_bar_rg.gif" width="14" height="32" /></td>
                        <td width="739" height="32" background="images/blue_bar_mid.gif">
						
						<table width="739" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="56" height="32" align="center" class="search-txt">Search</td>
                              <td width="139" align="left"><select name="scategory">
                                <option value="0"> Select One...</option>
                                <?
								  	$scat="select * from auc_categories where status='1'";
									$rscat=mysql_query($scat);
								  
										while($sscat=mysql_fetch_array($rscat)){
									?>
                                <option value="<?=$sscat['auto_id']?>">
                                <?=$sscat['catname']?>
                                </option>
                                <?
										}
									?>
                              </select></td>
                              <td width="300" align="left"><input name="search" type="text" size="50" /></td>
                              <td width="10">&nbsp;</td>
                              <td width="150" align="left" valign="middle"><input type="image" src="images/go.gif" width="25" height="25" border="0" /></a></td>
                              <td width="84">&nbsp;</td>
                            </tr>
                        </table>
						
						</td>
                        <td width="14" align="right"><img src="images/blue_bar_left.gif" width="14" height="32" /></td>
                      </tr>
                  </table></td>
                  <td width="6" align="right"></td>
                </tr>
            </table></td>
          </tr></form>
        </table></td>
      </tr>
    </table>