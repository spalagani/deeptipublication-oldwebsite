<?php
class DB 
{
  
  var $ident;
  var $sql = array('host'=>'localhost','user'=>'root','pass'=>'','db'=>'auction');
  //var $sql = array('host'=>'localhost','user'=>'seetrybu_auction','pass'=>'auction123','db'=>'seetrybu_auction');
  
  function connect ()
  {
     // Connect to MySQL
     $this->ident = mysql_connect($this->sql['host'], $this->sql['user'], $this->sql['pass']);
   
     // Select assigned DB
     if (!mysql_select_db($this->sql['db'])) {
       die("Could not connect to DB");
     }
  }

  

}
$DB = new DB();
$DB->connect();
function  delete_directory($dirname)  { 
        if  (is_dir($dirname)) 
                $dir_handle  =  opendir($dirname); 
        if  (!$dir_handle) 
                return  false; 
        while($file  =  readdir($dir_handle))  { 
                if  ($file  !=  "."  &&  $file  !=  "..")  { 
                        if  (!is_dir($dirname."/".$file)) 
                                unlink($dirname."/".$file); 
                        else 
                                delete_directory($dirname.'/'.$file);                        
                } 
        } 
        closedir($dir_handle); 
        rmdir($dirname); 
        return  true; 
} 
function getSqlQuery($query) {
	$result = mysql_query($query) or die(mysql_error().$query);	
	return $result;	
}
function getSqlFetch($rs) {
	$res = mysql_fetch_assoc($rs);	
	return $res;
}
function getSqlRow($query) {
	$result = mysql_query($query) or die(mysql_error());
	$row = mysql_fetch_array($result);
	mysql_free_result($result);
	return $row;
}

function getSqlNumber($sqlQuery) {
	$query=@mysql_query($sqlQuery);
	$result=@mysql_num_rows($query);
	@mysql_free_result($query);
	return $result;
}

function getSqlField($sqlQuery,$field) {
	$isQuery = getSqlNumber($sqlQuery);
	$query = @mysql_query($sqlQuery) or die (mysql_error()."<br>INVALID QUERY: ".$sqlQuery);
	if ($isQuery>0) {
		$result=@mysql_result($query,0,$field);
	} else $result="n/a";
	@mysql_free_result($query);
	return $result;
}
$settings=mysql_query("select * from nile_settings");
$rs_settings  = getSqlFetch($settings);
extract($rs_settings);
?>