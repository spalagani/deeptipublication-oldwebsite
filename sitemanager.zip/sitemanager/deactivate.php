<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
extract($_REQUEST);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>Welcome To Barzz.net Administration</TITLE>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<LINK 
href="images/style.css" type=text/css rel=stylesheet>
<META content="MSHTML 6.00.2900.2180" name=GENERATOR></HEAD>
<BODY leftMargin=30 topMargin=0 bgcolor="#F9F7F8">
<FORM name="formx" method="post">
&nbsp;



<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="100%">
<tr>
<td  align="center" class="normal style12">

<?php
$pid=trim($_GET['id']);
$presentdate=date("Y-m-d",time());
$sql="UPDATE tbl_barzz_users SET user_status=0 WHERE MD5(user_id)='$pid'";
$result = mysql_query($sql);

if($result && mysql_affected_rows()>0)
{
	$sql="SELECT * from tbl_barzz_users WHERE MD5(user_id)='$pid'";
	$result = mysql_query($sql);
	$row=mysql_fetch_assoc($result);
	$profile_id=$row['user_name'];
	/*code to send a mail */
include("../includes/class.phpmailer.php");
 $sub = "Status Mail - Barzz.net";
 $msg="<table>
 <tr>
 <td>Profile of $row[user_name] has been successfully DeActivated.</td>
 </tr>
 <tr><td>Contact the administrator for Activaation</td></tr></table> ";

	$mail = new PHPMailer();
	//$mail->IsMail();
	$mail->IsSMTP();// set mailer to use SMTP
	
	$mail->Host = "www.richerwebs.com";  // specify main and backup server
	$mail->SMTPAuth = true;     // turn on SMTP authentication
	$mail->Username = "phani@richerwebs.com";  // SMTP username
	$mail->Password = "rwphani"; // SMTP password
	$mail->From = "info@barzz.net";
    $mail->FromName = "Barzz.net";
	
	//$mail->AddAddress("$sa1[user_email]","Site Administrator");
	 $mail->AddAddress("$row[user_email]","Site Administrator");
	$mail->IsHTML(true);// set email format to HTML
	$mail->Subject = $sub;
	$mail->Body = $msg;
	$mail->AltBody = "This is the body in plain text for non-HTML mail clients";
	$mail->Send();
	header("location:users.php");
	//echo "Profile ($profile_id) has been successfully DeActivated.";
}
else
{
	echo "Profile ID doesn't exist.";
}
?></td>
</tr></table>


</FORM></BODY></HTML>
