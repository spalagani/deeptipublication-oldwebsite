<?php
ob_start();
session_start();
include('../includes/dbconfig.php');

$userid=$_REQUEST['username'];
$pwd=$_REQUEST['password'];
$curdate=date('y-m-d h:i:s');
	
	$sql=mysql_query("select * from  nile_admin where username='$userid' and password='$pwd' and status='1'");
	$resuser=mysql_fetch_array($sql);
	$num=mysql_num_rows($sql);

	if($num>=1)
	{
		$_SESSION['userid']=$userid;
		$_SESSION['admin_id']=$resuser['admin_id'];
		$_SESSION['level']=$resuser['level'];		
		header("location:adminctrl.php");
		exit;
	}
	else
	{
		
		header("location:login_index.php");
		exit;
	}
?>