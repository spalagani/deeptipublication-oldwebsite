<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>Welcome To  Administration</TITLE>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<LINK 
href="images/style.css" type=text/css rel=stylesheet>
<META content="MSHTML 6.00.2900.2180" name=GENERATOR></HEAD>
<BODY leftMargin=30 topMargin=0 >
<FORM name="formx" method="post">
<TABLE cellSpacing=0 cellPadding=0 width="100%" align=center border=0>
  <TBODY>
  <?php
  error_reporting(0);
  session_start();
$level=$_SESSION['level'];
  //echo $level;exit;//if($level){?>
  
  <tr><td>&nbsp;
  </td></tr>
  <TR>
    <!--<TD><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr align="left" valign="top">
        <td height="11" colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="1%" align="right" valign="top"><img src="images/top_left_corner.jpg" width="8" height="22" /></td>
              <td width="8%" height="11" align="center" valign="top"><table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="5" height="10" align="center" valign="top" class="style1"></td>
                    <td align="center" valign="top" class="style1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td width="5"></td>
                          <td align="center" class="greentextbold">Configuration</td>
                          <td width="5"></td>
                        </tr>
                    </table></td>
                    <td width="5" align="center" valign="top" class="style1"></td>
                  </tr>
                  <tr>
                    <td height="4" align="center" valign="top"></td>
                    <td align="center" valign="top"></td>
                    <td align="center" valign="top"></td>
                  </tr>
              </table></td>
              <td width="90%" height="14" background="images/bgline.jpg"></td>
              <td align="left" valign="top"><img src="images/top_rgt_corner.jpg" width="5" height="22" /></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td width="8"  background="images/bglfrt.jpg"></td>
        <td width="100%" align="left" valign="top"><table width="100%">
            <tr>
              <td width="18">&nbsp;</td>
			  <td width="18"><img src="images/cpanel.gif" alt="Settings" width="18" height="18"></td>
              <td width="107" class="normal"><a href="users.php?act=view" class="greenlink"></a><a href="settings.php?act=view" class="greenlink">Settings</a></td>
			  
			  <td width="16">&nbsp;</td>
			  <td width="15">&nbsp;</td>
              <td width="615" class="normal">&nbsp;</td>
              <td width="38" class="normal">&nbsp;</td>
              </tr>
        </table></td>
        <td width="5" background="images/bgrgt.jpg" bgcolor="#F8F6F9"></td>
      </tr>
      <tr>
        <td align="center" valign="top"><img src="images/lft-btm.jpg" width="8" height="6" /></td>
        <td height="6" background="images/bgbtm.jpg"></td>
        <td align="left" valign="top"><img src="images/btm-rgt.jpg" width="5" height="6" /></td>
      </tr>
    </table></TD></TR>
	
	
  <TR>
    <TD>&nbsp;</TD></TR>
	<TR>
	  <TD><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr align="left" valign="top">
          <td height="11" colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="1%" align="right" valign="top"><img src="images/top_left_corner.jpg" width="8" height="22" /></td>
                <td width="8%" height="11" align="center" valign="top"><table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="5" height="10" align="center" valign="top" class="style1"></td>
                      <td align="center" valign="top" class="style1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="5"></td>
                            <td align="center" class="greentextbold">&nbsp;User&nbsp;Manager&nbsp;</td>
                            <td width="5"></td>
                          </tr>
                      </table></td>
                      <td width="5" align="center" valign="top" class="style1"></td>
                    </tr>
                    <tr>
                      <td height="4" align="center" valign="top"></td>
                      <td align="center" valign="top"></td>
                      <td align="center" valign="top"></td>
                    </tr>
                </table></td>
                <td width="90%" height="14" background="images/bgline.jpg"></td>
                <td align="left" valign="top"><img src="images/top_rgt_corner.jpg" width="5" height="22" /></td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td width="8"  background="images/bglfrt.jpg"></td>
          <td width="100%" align="left" valign="top"><table width="100%">
              <tr>
                
				<td width="13">&nbsp;</td>
                <td width="16"><img src="images/admin.gif" alt="Admin" width="16" height="16"></td>
                <td width="80" class="normal"><a href="users.php?act=view" class="greenlink"></a><a href="admin.php?act=view" class="greenlink">Administrator</a></td>
				
                <td width="15">&nbsp;</td>
                <td width="24"><img src="images/user.gif" alt="Users" width="16" height="16"></td>
                <td width="65"><a href="users.php?act=view" class="greenlink">Users</a></td>
                <td width="11">&nbsp;</td>
                <td width="140" class="normal"><a href="precommusers.php?act=view" class="greenlink"></a><a href="admin.php?act=view" class="greenlink"></a></td>
                <td width="219" class="normal"><a href="users.php?act=view" class="greenlink"></a><a href="admin.php?act=view" class="greenlink"></a></td>
                <td width="16" class="normal">&nbsp;</td>
              </tr>
          </table></td>
          <td width="5" background="images/bgrgt.jpg" bgcolor="#F8F6F9"></td>
        </tr>
        <tr>
          <td align="center" valign="top"><img src="images/lft-btm.jpg" width="8" height="6" /></td>
          <td height="6" background="images/bgbtm.jpg"></td>
          <td align="left" valign="top"><img src="images/btm-rgt.jpg" width="5" height="6" /></td>
        </tr>
      </table></TD>-->
	  </TR>
	  
	  <TR>
    <TD>&nbsp;</TD></TR>
	  
	<tr><td>
	<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr align="left" valign="top">
    <td height="11" colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="1%" align="right" valign="top"><img src="images/top_left_corner.jpg" width="8" height="22" /></td>
        <td width="8%" height="11" align="center" valign="top"><table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="5" height="10" align="center" valign="top" class="style1"></td>
            <td align="center" valign="top" class="style1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="5"></td>
                <td align="center" class="greentextbold">&nbsp;Business&nbsp;Manager&nbsp;</td>
                <td width="5"></td>
              </tr>
            </table></td>
            <td width="5" align="center" valign="top" class="style1"></td>
          </tr>
          <tr>
            <td height="4" align="center" valign="top"></td>
            <td align="center" valign="top"></td>
            <td align="center" valign="top"></td>
          </tr>
        </table></td>
        <td width="90%" height="14" background="images/bgline.jpg"></td>
        <td align="left" valign="top"><img src="images/top_rgt_corner.jpg" width="5" height="22" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="8"  background="images/bglfrt.jpg"></td>
    <td width="100%" align="left" valign="top"><table width="100%">
      <tr>
        <td width="18">&nbsp;</td>
        <td width="16"><img src="images/category.gif" alt="Categories" width="16" height="16"></td>
        <td width="65" class="normal"><a href="categories.php?act=view" class="greenlink">Categories</a></td>
        <td width="26">&nbsp;</td>
        <td width="16"><img src="images/category.gif" alt="Categories" width="16" height="16"></td>
        <td width="116" class="normal"><a href="subcategories.php?act=view" class="greenlink">Sub Categories</a></td>
		<td width="24">&nbsp;</td>
        <td width="28" class="normal"><img src="images/subcat.gif" alt="Auctions" width="16" height="16"></td>
        <td width="533" class="normal"><a href="items.php?act=view" class="greenlink">Add Books </a><a href="items.php?act=view" class="greenlink"></a>&nbsp;</td>
      </tr>
    </table></td>
    <td width="5" background="images/bgrgt.jpg" bgcolor="#F8F6F9"></td>
  </tr>
  <tr>
    <td align="center" valign="top"><img src="images/lft-btm.jpg" width="8" height="6" /></td>
    <td height="6" background="images/bgbtm.jpg"></td>
    <td align="left" valign="top"><img src="images/btm-rgt.jpg" width="5" height="6" /></td>
  </tr>
</table>
	</td></tr>
	 
	
	 <TR>
	   <TD>&nbsp;</TD>
      </TR>
	  
	<tr><td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr align="left" valign="top">
        <td height="11" colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="1%" align="right" valign="top"><img src="images/top_left_corner.jpg" width="8" height="22" /></td>
              <td width="8%" height="11" align="center" valign="top"><table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="5" height="10" align="center" valign="top" class="style1"></td>
                    <td align="center" valign="top" class="style1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td width="5"></td>
                          <td align="center" class="greentextbold">&nbsp;Tools&nbsp;</td>
                          <td width="5"></td>
                        </tr>
                    </table></td>
                    <td width="5" align="center" valign="top" class="style1"></td>
                  </tr>
                  <tr>
                    <td height="4" align="center" valign="top"></td>
                    <td align="center" valign="top"></td>
                    <td align="center" valign="top"></td>
                  </tr>
              </table></td>
              <td width="91%" height="14" background="images/bgline.jpg"></td>
              <td align="left" valign="top"><img src="images/top_rgt_corner.jpg" width="5" height="22" /></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td  background="images/bglfrt.jpg"></td>
        <td align="left" valign="top"><table width="100%">
            <tr>
              <td width="13">&nbsp;</td>
              <td width="16"><img src="images/email.gif" alt="Articles" width="16" height="16"></td>
              <td width="55" align="left" class="normal"><a href="news.php?act=view" class="greenlink">Articles </a></td>
              <td width="13">&nbsp;</td>
              <td width="27"><img src="images/muser.gif" alt="Newsletter users" width="16" height="16"></td>
              <td width="145" align="left" class="normal"><a href="newsletter_users.php?act=view" class="greenlink">Newsletter Users </a></td>
			  <td width="16">&nbsp;</td>
              <td width="44">&nbsp;</td>
              <td width="144" align="left" class="normal">&nbsp;</td>
<!--              <td width="21">&nbsp;</td>
              <td width="308" class="normal"><a href="products.php?act=view" class="greenlink"></a></td>
--> 
             <!-- <td width="16" align="left"><img src="images/music.gif" alt="Upload Video" width="16" height="16"></td>
              <td width="117" align="left" class="normal"><a href="uploadvideo.php?act=view" class="greenlink">Upload Video</a></td>-->
              <td width="16" align="left">&nbsp;</td>
              <td width="322" align="left" class="normal">&nbsp;</td>
            </tr>
        </table></td>
        <td background="images/bgrgt.jpg" bgcolor="#F8F6F9"></td>
      </tr>
      <tr>
        <td width="8" align="center" valign="top"><img src="images/lft-btm.jpg" width="8" height="6" /></td>
        <td width="100%" height="6" background="images/bgbtm.jpg"></td>
        <td width="5" align="left" valign="top"><img src="images/btm-rgt.jpg" width="5" height="6" /></td>
      </tr>
    </table></td></tr>
	
	
	 <TR>
    <TD>&nbsp;</TD></TR>
	
	<td>
	<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr align="left" valign="top">
    <td height="11" colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="1%" align="right" valign="top"><img src="images/top_left_corner.jpg" width="8" height="22" /></td>
        <td width="8%" height="11" align="center" valign="top"><table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="5" height="10" align="center" valign="top" class="style1"></td>
            <td align="center" valign="top" class="style1"><table width="227%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="5"></td>
                <td align="center" class="greentextbold">&nbsp;Static&nbsp;Pages&nbsp;</td>
                <td width="5"></td>
              </tr>
            </table></td>
            <td width="5" align="center" valign="top" class="style1"></td>
          </tr>
          <tr>
            <td height="4" align="center" valign="top"></td>
            <td align="center" valign="top"></td>
            <td align="center" valign="top"></td>
          </tr>
        </table></td>
        <td width="90%" height="14" background="images/bgline.jpg"></td>
        <td align="left" valign="top"><img src="images/top_rgt_corner.jpg" width="5" height="22" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="8"  background="images/bglfrt.jpg"></td>
    <td width="100%" align="left" valign="top"><table width="100%">
      <tr>
        <td width="24">&nbsp;</td>
        <td width="34"><img src="images/media.gif" alt="Categories" width="16" height="16"></td>
        <td width="172" class="normal"><a href="staticpages.php?act=view" class="greenlink">View Static Pages </a></td>
        <td width="20">&nbsp;</td>
<!--        <td width="16"><img src="images/media.gif" alt="quotes" width="16" height="16"></td>
        <td width="169" class="normal"><a href="staticpages.php?act=edit" class="greenlink">Edit Static Page </a></td>
-->		<td width="208">&nbsp;</td>
        <td width="37" class="normal">&nbsp;</td>
        <td width="359" class="normal">&nbsp;</td>
      </tr>
    </table></td>
    <td width="5" background="images/bgrgt.jpg" bgcolor="#F8F6F9"></td>
  </tr>
  <tr>
    <td align="center" valign="top"><img src="images/lft-btm.jpg" width="8" height="6" /></td>
    <td height="6" background="images/bgbtm.jpg"></td>
    <td align="left" valign="top"><img src="images/btm-rgt.jpg" width="5" height="6" /></td>
  </tr>
</table>	</td>
	 
	 
	 
	
	
	 <TR>
    <TD>&nbsp;</TD></TR>
	
	
	
	<tr><td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr align="left" valign="top">
        <td height="11" colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="1%" align="right" valign="top"><img src="images/top_left_corner.jpg" width="8" height="22" /></td>
              <td width="8%" height="11" align="center" valign="top"><table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="5" height="10" align="center" valign="top" class="style1"></td>
                    <td align="center" valign="top" class="style1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td width="5"></td>
                          <td align="center" class="greentextbold">&nbsp;Others&nbsp;</td>
                          <td width="5"></td>
                        </tr>
                    </table></td>
                    <td width="5" align="center" valign="top" class="style1"></td>
                  </tr>
                  <tr>
                    <td height="4" align="center" valign="top"></td>
                    <td align="center" valign="top"></td>
                    <td align="center" valign="top"></td>
                  </tr>
              </table></td>
              <td width="91%" height="14" background="images/bgline.jpg"></td>
              <td align="left" valign="top"><img src="images/top_rgt_corner.jpg" width="5" height="22" /></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td  background="images/bglfrt.jpg"></td>
        <td align="left" valign="top"><table width="100%">
            <tr>
             
			 <!-- <td width="21">&nbsp;</td>
              <td width="17"><img src="images/report.gif" alt="Logout" width="17" height="16"></td>
              <td width="36" align="left" class="normal"><a href="cms.php?act=view" class="greenlink">CMS </a></td>-->
			 
              <td width="15">&nbsp;</td>
              <td width="16"><img src="images/logout.gif" alt="Logout" width="16" height="16"></td>
              <td width="141" align="left" class="normal"><a href="logout.php" target="_top" class="greenlink">Logout</a></td>
              <td width="11">&nbsp;</td>
              <td width="15">&nbsp;</td>
              <td width="547" class="normal"><a href="products.php?act=view" class="greenlink"></a></td>
            </tr>
        </table></td>
        <td background="images/bgrgt.jpg" bgcolor="#F8F6F9"></td>
      </tr>
      <tr>
        <td width="8" align="center" valign="top"><img src="images/lft-btm.jpg" width="8" height="6" /></td>
        <td width="100%" height="6" background="images/bgbtm.jpg"></td>
        <td width="5" align="left" valign="top"><img src="images/btm-rgt.jpg" width="5" height="6" /></td>
      </tr>
    </table></td></tr>
	</TBODY></TABLE>
</FORM></BODY></HTML>
