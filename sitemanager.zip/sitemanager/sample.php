<?php

/*include "slideshow.php";

//add 3 slides and give each a different slide duration
$slideshow[ 'slide' ][ 0 ] = array ( 'url' => "images/bar_image.jpg", 'duration' => 20 );
$slideshow[ 'slide' ][ 1 ] = array ( 'url' => "images/bar_three.jpg", 'duration' => 10);
$slideshow[ 'slide' ][ 2 ] = array ( 'url' => "images/Beer_Types.jpg", 'duration' => 6 );
							
Send_Slideshow_Data ( $slideshow );*/

//include 'slideshow.php';

//$slideshow[ 'music' ] = array ( 'url'=>"sound/slow.mp3", 'loop'=>true, 'stream'=>true );

/*for ( $i=0; $i<5; $i++){
    $slideshow[ 'slide' ][ $i ] = array ( 'url'=>"images/bar$i.jpg", 'background'=>"000000" );
    $slideshow[ 'transition' ][ $i ] = array ( 'type'=>"push_left" );
    $slideshow[ 'motion' ][ $i ] = array ( 'duration'=>2, 'start_xOffset'=>-200 );
}

$slideshow[ 'draw_text' ][ 0 ] = array ( array ( 'x'         =>  15, 
                                                 'align'     =>  "left", 
                                                   
                                                 'bold'      =>  true, 
                                                 'size'      =>  30, 
                                                 'color'     =>  "ffffff", 
                                                 'alpha'     =>  75
                                             )
                                     );

Send_Slideshow_Data ( $slideshow );*/



?>
<!--<font color="#E38898"-->
<?php
include 'slideshow.php';



$slideshow[ 'music' ] = array ( 'url'=>"sound/slow.mp3", 'loop'=>true, 'stream'=>true );

for ( $i=0; $i<3; $i++){
    $slideshow[ 'slide' ][ $i ] = array ( 'url'=>"mingwin/", 'background'=>"000000" );
    //$slideshow[ 'transition' ][ $i ] = array ( 'type'=>"push_left" );
    $slideshow[ 'motion' ][ $i ] = array ( 'duration'=>2, 'start_xOffset'=>-200 );
}

/*$slideshow[ 'draw_text' ][ 0 ] = array ( array ( 'x'         =>  15, 
                                                 'align'     =>  "left", 
                                                   
                                                 'bold'      =>  true, 
                                                 'size'      =>  30, 
                                                 'color'     =>  "ffffff", 
                                                 'alpha'     =>  75
                                             )
                                     );
*/
Send_Slideshow_Data ( $slideshow );
?>