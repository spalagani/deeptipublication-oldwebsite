<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');

 $id=$_REQUEST['id'];
 $admin=$_POST['admin'];
 $user=$_POST['user'];
 $bar=$_POST['bar'];
 $cock=$_POST['cock'];
$toast=$_POST['toast'];
$scotch=$_POST['scotch'];
 $wine=$_POST['wine'];
 $beer=$_POST['beer'];
 $cigar=$_POST['cigar'];
$bands=$_POST['bands'];
 $picture=$_POST['picture'];
  $job=$_POST['job'];
$proff=$_POST['proff'];
 $vendor=$_POST['vendor'];
 $forum=$_POST['forum'];
 $poll=$_POST['poll'];
 $event=$_POST['event'];
 $column=$_POST['column'];
 $annoumcement=$_POST['annoumcement'];
 $homepage=$_POST['homepage'];
 // $banner=$_POST['banner'];
 $advhome=$_POST['advhome'];
 $advtopic=$_POST['advtopic'];
 $advservice=$_POST['advservice'];
 $aboutus=$_POST['aboutus'];
 $advcity=$_POST['advcity'];
 $sql=mysql_query("delete from tbl_barzz_adminpermission where admin_id='$id'");
$sql=mysql_query("insert into  tbl_barzz_adminpermission  values('$id', '$admin' ,'$user' , '$bar',  '$cock' ,'$toast', '$scotch' ,'$wine' , '$beer',  '$cigar' ,'$bands', '$picture','$job' ,'$proff' , '$vendor',  '$forum' ,'$poll', '$event' ,'$column' , '$annoumcement',  '$homepage','$advhome','$advtopic','$advcity','$advservice','$aboutus' )");

	header("location:admin.php");
	exit;
?>