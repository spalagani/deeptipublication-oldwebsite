<?php
ob_start();
require_once('sessionchk.php');
include('../includes/dbconfig.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>Left Menu Style</TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>
<script language="javascript" type="text/javascript" src="js/ua.js"></script>
<script language="javascript" type="text/javascript" src="js/PanelBar.js"></script>
<script language=javascript>

function hidestatus(){
window.status=''
return true
}

if (document.layers)
document.captureEvents(Event.MOUSEOVER | Event.MOUSEOUT)

document.onmouseover=hidestatus
document.onmouseout=hidestatus


</script>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><style type="text/css">
<!--
body {
	background-color: #F39542;
}
-->
</style></HEAD>
<?php
$ok=$_REQUEST['ok'];
if($ok=='logout')
{
	$stime=$_SESSION['stime'];
	$uid=$_SESSION['aid'];
	$_SESSION['userid']="";
	header("location:index.html");
	exit;
}
//$level=$_SESSION['level'];
//echo $level;exit;
?>
<BODY topmargin="1" onload='javascript:hidestatus();' >
<form  name='formx' method='post'>
<table width="18%" border="0" align="center" cellpadding="0" cellspacing="0" >

<tr>
	<td>
	
	<!--<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("Configuration", "", "");
		objTmp.x1123687333493("Settings", "settings.php?act=view", "", "", "cpanel.gif", "main");
			
		
		objContainer.x1123687333480(150);
	</script>-->
	</td>
</tr>

<tr>
	<td>
	
	<!--<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("User Manager", "", "");
		
			objTmp.x1123687333493("Administrator", "admin.php?act=view", "", "", "admin.gif", "main");
		
		objTmp.x1123687333493("Users", "users.php?act=view", "", "", "user.gif", "main");
		
	
		
		
		objContainer.x1123687333480(150);
	</script>
	-->
	</td>
</tr>



<tr>
<td>
<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("Business Manager", "", null);
		objTmp.x1123687333493("Categories", "categories.php?act=view", "", "", "category.gif", "main");
		objTmp.x1123687333493("Sub Categories", "subcategories.php?act=view", "", "", "category.gif", "main");
		objTmp.x1123687333493("Add Books", "items.php?act=view", "", "", "subcat.gif", "main");

		objContainer.x1123687333480(150);
	</script>
</td></tr>


<tr>
<td>
<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("Orders", "", null);
		
		objTmp.x1123687333493("Orders", "orders.php?act=view", "", "", "report.gif", "main");
		
		
		objContainer.x1123687333480(150);
	</script>
</td></tr>



<tr>
<td>
<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("Tools", "", null);
		
		objTmp.x1123687333493("Articles", "news.php?act=view", "", "", "report.gif", "main");
		objTmp.x1123687333493("Newsletter Users", "newsletter_users.php?act=view", "", "", "muser.gif", "main");
		
		objContainer.x1123687333480(150);
	</script>
</td></tr>

<tr>
<td>
<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("Static Pages", "", null);
		objTmp.x1123687333493("View Static Pages", "staticpages.php?act=view", "", "", "media.gif", "main");
		//objTmp.x1123687333493("Key Books", "keybooks.php?act=view", "", "", "media.gif", "main");
		//objTmp.x1123687333493("Request Catalog", "catalogs.php?act=view", "", "", "media.gif", "main");
		//x1123687333540("XPOlive.css", null, null)
		objContainer.x1123687333480(150);
	</script>
</td></tr>
<tr>
<td>
<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("Others", "", null);
	
		objTmp.x1123687333493("Logout", "logout.php", "", "", "logout.gif", "_top");
	x1123687333540("XPOlive.css", null, null)
		objContainer.x1123687333480(150);
	</script>
</td></tr>

<?php /*?><tr>
<td>
<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("Auction Manager", "", null);
		objTmp.x1123687333493("Seller Auction", "sellers.php?act=view", "", "", "shp.gif", "main");
		
			objTmp.x1123687333493("Approve Winner", "ratings.php?act=view", "", "", "report.gif", "main");
			objTmp.x1123687333493("Kitty", "kitty.php?act=view", "", "", "category.gif", "main");
			objTmp.x1123687333493("Winners", "winners.php?act=view", "", "", "category.gif", "main");
		
		x1123687333540("XPOlive.css", null, null)
		objContainer.x1123687333480(150);
	</script>
</td></tr>



<tr>
<td>
<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("Precommercial", "", null);
		objTmp.x1123687333493("Pre Commercial", "precomm.php?act=view", "", "", "subcat.gif", "main");
		
			objTmp.x1123687333493("Approve Prewinner", "preratings.php?act=view", "", "", "report.gif", "main");
			<!--objTmp.x1123687333493("Precommercial Kitty", "prekitty.php?act=view", "", "", "category.gif", "main");-->
			objTmp.x1123687333493("Winners", "prewinners.php?act=view", "", "", "category.gif", "main");
		
		objContainer.x1123687333480(150);
	</script>
</td></tr>



<tr>
<td>
<script language="javascript">
		var objContainer;
		var objTmp;

        objContainer = x1123687333538();
		objTmp = objContainer.x1123687333479("Advertisers", "", null);
		
		objTmp.x1123687333493("Advertisers", "advertiser.php?act=view", "", "", "user.gif", "main");
		objTmp.x1123687333493("Banners", "banner.php?act=view", "", "", "media.gif", "main");
		
		objContainer.x1123687333480(150);
	</script>
</td></tr><?php */?>





</table>
</form>
</BODY>
</HTML>
