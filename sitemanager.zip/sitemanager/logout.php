<?
ob_start();
session_start();
$_SESSION[userid]="";
$_SESSION[aid]="";
session_destroy();
header("Location:index.php");
?>
