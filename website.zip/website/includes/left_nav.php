<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: 12px}
-->
</style>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="204" height="33" align="left" background="images/left_heading_bg.jpg" class="add" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Categories </td>
          </tr>
          <tr>
            <td background="images/index_design_36.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="9%" height="27">&nbsp;</td>
                <td width="64%" align="left" class="footertext style1"><a href="deepti_textbooks.php" class="footertext">Text Books</a> </td>
                <td width="27%"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
              <tr>
                <td height="27">&nbsp;</td>
                <td height="27" align="left" class="footertext style1"><a href="deepti_questionbanks.php" class="footertext">Question Banks </a></td>
                <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
              <tr>
                <td height="27">&nbsp;</td>
                <td height="27" align="left" class="footertext style1"><a href="deepti_studymaterials.php" class="footertext">Study Materials</a></td>
                <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
              <tr>
                <td height="27">&nbsp;</td>
                <td height="27" align="left" class="footertext style1"><a href="deepti_eamcetbooks.php?subcategory=13" class="footertext">Eamcet</a> </td>
                <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
              <tr>
                <td height="27">&nbsp;</td>
                <td height="27" align="left" class="footertext style1"><a href="otherbooks.php?subcategory=14" class="footertext">Other books </a></td>
                <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td><img src="images/-left_bottom_bg.jpg" width="203" height="3" /></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align="center" valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td align="center" valign="top"><table width="200" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>
			<script type="text/javascript"><!--
google_ad_client = "ca-pub-3345468433035998";
/* SMSSite Home page left */
google_ad_slot = "5120534385";
google_ad_width = 200;
google_ad_height = 200;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
