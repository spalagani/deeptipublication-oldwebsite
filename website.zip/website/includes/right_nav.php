<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {color: #477CB2}
.style3 {font-size:12px; font-weight:bold; text-decoration:none; text-transform:uppercase; padding:4px; font-family: tahoma, Arial, Helvetica, sans-serif;}
-->
</style>
<script type="text/javascript">
function loginvalidate()
{
	var username = document.forml.email.value;
	var password = document.forml.password.value;
	
	
	var emailFormat = /^\w(\.?[\w-])*@\w(\.?[\w-])*\.[a-zA-Z]{2,6}(\.[a-zA-Z]{2})?$/;
		
	
		if(username == "")
		{
			alert("Please enter User Name.");
			document.forml.email.focus();
			return false;
		}	
		if(username!= "")
		{	
		 	var eres=username.search(emailFormat);
			if(eres == -1)
			{
				alert("Please Enter Valid Email Id ");
				document.forml.email.focus();
				return false;
			}
		}
		if(password == "")
		{	
			alert("Please enter Password.");
			document.forml.password.focus();
			return false;
		}
				return true;
	
}
</script>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="left"><span class="style2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style3">Shopping Cart </span></span></td>
      </tr>
      <tr>
        <td height="41" align="center" background="images/-rightside_body_bg.jpg" class="bold_txt1" style="background-repeat:repeat-y">
		<?php if(!isset($_SESSION['tot_quantity'])){
		  $items=0; 
		  echo "No Books "."<br/>"."Available in Cart";
		  }
  else{
  $items=$_SESSION['tot_quantity'];
  ?>
<a href="cart.php">View Cart</a>
  <?php
  
  }
  ?></td>
      </tr>
      <tr>
        <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="add">Login</span></td>
      </tr>
      <tr>
        <td background="images/-rightside_body_bg.jpg" style="background-repeat:repeat-y" align="center">
		<?php if(!isset($_SESSION['uname'])){ ?>
		<form action="login.php?ok=check" method="post" name="forml" id="forml" onsubmit="javascript:return loginvalidate()">
                                                <input type="hidden" name="dd" value="<?php echo $dd?>" />
          <table width="100%" border="0" cellspacing="4" cellpadding="0">
            <tr>
              <td width="47%" align="right" class="brown_txt">UserName : </td>
              <td width="53%" align="left"><input name="email" type="text" size="12" /></td>
            </tr>
            <tr>
              <td align="right" class="brown_txt">Password : </td>
              <td align="left"><input name="password" type="password" size="12" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td align="left"><input type="submit" name="submit" value="submit" class="textfield" /></td>
            </tr>
            <tr>
              <td colspan="2">&nbsp;</td>
            </tr>
          </table>
        </form>
		<?php }else{ ?>
		
		<table width="100%" border="0" cellpadding="0" cellspacing="5">
  <tr>
    <td class="style3"><a href="myaccount.php">My Account</a></td>
  </tr>
  <tr>
    <td class="style3"><a href="logout.php">LogOut</a></td>
  </tr>
</table>

		<?php } ?>
		</td>
      </tr>
      <tr>
        <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="add">Feedback / Request</span></td>
      </tr>
      <tr>
        <td background="images/-rightside_body_bg.jpg" style="background-repeat:repeat-y" align="center"><a href="Contactus.php#fed"><img src="images/feedback.jpg" width="169" height="211" border="0" /></a></td>
      </tr>
      <tr>
        <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td background="images/-rightside_body_bg.jpg" style="background-repeat:repeat-y" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>