<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {color: #477CB2}
.style3 {font-size:12px; font-weight:bold; text-decoration:none; text-transform:uppercase; padding:4px; font-family: tahoma, Arial, Helvetica, sans-serif;}
-->
</style>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="left"><span class="style2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style3">Shopping Cart </span></span></td>
      </tr>
      <tr>
        <td height="41" align="center" background="images/-rightside_body_bg.jpg" class="bold_txt1" style="background-repeat:repeat-y">
             <a href="cart.php"><?php if(!isset($_SESSION['tot_quantity'])){
  $items=0; 
        echo " No Books Available"."<br/>"." in your Cart";}
  else{
  $items=$_SESSION['tot_quantity'];
echo $items. " Books Available";}
  ?>      </a>
           </td>
      </tr>
      <tr>
        <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="add">Login</span></td>
      </tr>
      <tr>
        <td background="images/-rightside_body_bg.jpg" style="background-repeat:repeat-y" align="center"><form id="form1" name="form1" method="post" action="">
          <table width="100%" border="0" cellspacing="4" cellpadding="0">
            <tr>
              <td width="47%" align="right" class="brown_txt">UserName : </td>
              <td width="53%" align="left"><input name="textfield" type="text" size="12" /></td>
            </tr>
            <tr>
              <td align="right" class="brown_txt">Password : </td>
              <td align="left"><input name="textfield2" type="text" size="12" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td align="left"><input type="submit" name="Submit" value="Submit" /></td>
            </tr>
            <tr>
              <td colspan="2">&nbsp;</td>
            </tr>
          </table>
        </form></td>
      </tr>
      <tr>
        <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="add">Request call Back </span></td>
      </tr>
      <tr>
        <td background="images/-rightside_body_bg.jpg" style="background-repeat:repeat-y" align="center"><form id="form2" name="form2" method="post" action="">
          <table width="100%" border="0" cellspacing="4" cellpadding="0">
            <tr>
              <td width="47%" align="right" class="brown_txt">Name  : </td>
              <td width="53%" align="left"><input name="textfield3" type="text" size="12" /></td>
            </tr>
            <tr>
              <td align="right" class="brown_txt">Email : </td>
              <td align="left"><input name="textfield22" type="text" size="12" /></td>
            </tr>
            <tr>
              <td align="right" class="brown_txt">Reason : </td>
              <td align="left"><textarea name="textfield22" cols="12"></textarea></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><input type="submit" name="Submit2" value="Submit" /></td>
            </tr>
          </table>
        </form></td>
      </tr>
      <tr>
        <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td background="images/-rightside_body_bg.jpg" style="background-repeat:repeat-y" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
