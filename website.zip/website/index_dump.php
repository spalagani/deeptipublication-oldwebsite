<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #686868;
}
-->
</style>
<link href="CSS/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {font-size: 12px}
.style2 {color: #477CB2}
.style3 {font-size:12px; font-weight:bold; text-decoration:none; text-transform:uppercase; padding:4px; font-family: tahoma, Arial, Helvetica, sans-serif;}
.style4 {font-size: 13px}
-->
</style>
</head>

<body>
<table width="996" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/Top_corner.jpg" width="996" height="10" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF"><table width="96%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>
			<!---Start Head of the page -->
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="35%"><img src="images/Deeptipublishers-logo.jpg" width="332" height="106" /></td>
                    <td width="65%" valign="bottom"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td>&nbsp;</td>
                            <td width="101" align="center" background="images/top_button.jpg" class="agentadmin">Home</td>
                            <td width="5">&nbsp;</td>
                            <td width="101" align="center" background="images/top_button.jpg" class="agentadmin">About Us </td>
                            <td width="5">&nbsp;</td>
                            <td width="101" align="center" background="images/top_button.jpg" class="agentadmin">Shopping Cart </td>
                            <td width="5">&nbsp;</td>
                            <td width="101" height="31" align="center" background="images/top_button.jpg" class="agentadmin">Contact Us </td>
                          </tr>
                        </table></td>
                        <td width="5">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="7"><img src="images/searchleft.jpg" width="7" height="72" /></td>
                    <td background="images/search_bg.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td height="35"><form id="form3" name="form3" method="post" action="">
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="8%" class="footer2 style4">Search : </td>
                              <td width="15%"><label>
                                <input name="textfield4" type="text" value="Keyword" />
                              </label></td>
                              <td width="1%">&nbsp;</td>
                              <td width="9%"><select name="select">
                                <option>Categories</option>
                              </select>                              </td>
                              <td width="67%"><input type="submit" name="Submit3" value="GO" /></td>
                            </tr>
                          </table>
                                                </form>
                        </td>
                      </tr>
                      <tr>
                        <td height="35"><div class="avail"><marquee>Welcome to DeeptiPublication</marquee></div></td>
                      </tr>
                    </table></td>
                    <td width="5"><img src="images/searchright.jpg" width="5" height="72" /></td>
                  </tr>
                </table></td>
              </tr>
            </table>
			<!---END  Head of the page -->			</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            </tr>
          <tr>
            <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="203" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td width="204" height="33" align="left" background="images/left_heading_bg.jpg" class="add" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Categories </td>
                              </tr>
                              <tr>
                                <td background="images/index_design_36.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td width="9%" height="27">&nbsp;</td>
                                      <td width="64%" align="left" class="footertext style1"><a href="#" class="footertext">Text Books</a> </td>
                                      <td width="27%"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
                                    </tr>
                                    <tr>
                                      <td height="27">&nbsp;</td>
                                      <td height="27" align="left" class="footertext style1"><a href="#" class="footertext">Question Banks </a></td>
                                      <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
                                    </tr>
                                    <tr>
                                      <td height="27">&nbsp;</td>
                                      <td height="27" align="left" class="footertext style1"><a href="#" class="footertext">Study Materials</a></td>
                                      <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
                                    </tr>
                                    <tr>
                                      <td height="27">&nbsp;</td>
                                      <td height="27" align="left" class="footertext style1"><a href="#" class="footertext">Eamcet</a> </td>
                                      <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
                                    </tr>
                                    <tr>
                                      <td height="27">&nbsp;</td>
                                      <td height="27" align="left" class="footertext style1"><a href="#" class="footertext">Other books </a></td>
                                      <td height="27"><img src="images/left_arrow.jpg" width="6" height="7" /></td>
                                    </tr>
                                </table></td>
                              </tr>
                              <tr>
                                <td><img src="images/-left_bottom_bg.jpg" width="203" height="3" /></td>
                              </tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td align="center" valign="top">&nbsp;</td>
                        </tr>
                        <tr>
                          <td align="center" valign="top">&nbsp;</td>
                        </tr>
                    </table></td>
                  </tr>
                </table></td>
                <td valign="top"><table width="97%" border="0" align="right" cellpadding="0" cellspacing="2">
                  <tr>
                    <td><img src="images/index_design_21.jpg" width="566" height="211" /></td>
                  </tr>
                  <tr>
                    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td><table width="567" border="0" cellpadding="0" cellspacing="0" s>
                          <tr>
                            <td width="10"><img src="images/-Featured_products_left_cor.jpg" width="10" height="34" /></td>
                            <td width="565" background="images/-Featured_products_top_bg.jpg"><span class="add">&nbsp;Featured Products </span></td>
                            <td width="9"><img src="images/-Featured_products_top_righ.jpg" width="9" height="34" /></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td align="center" background="images/-Featured_products_body_bg.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td><div>
                              <table width="100%" border="0" cellspacing="2" cellpadding="0">
                                <tr>
                                  <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                      <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td width="31%"><table width="25%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tr>
                                          <td><img src="images/book.jpg" width="109" height="148" /></td>
                                        </tr>
                                        <tr>
                                          <td height="25" align="center" class="bold_txt">Mathematics</td>
                                        </tr>
                                      </table></td>
                                      <td width="30%"><table width="25%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tr>
                                          <td><img src="images/book.jpg" width="109" height="148" /></td>
                                        </tr>
                                        <tr>
                                          <td height="25" align="center" class="bold_txt">Mathematics</td>
                                        </tr>
                                      </table></td>
                                      <td width="30%"><table width="25%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tr>
                                          <td><img src="images/book.jpg" width="109" height="148" /></td>
                                        </tr>
                                        <tr>
                                          <td height="25" align="center" class="bold_txt">Mathematics</td>
                                        </tr>
                                      </table></td>
                                    </tr>
                                  </table></td>
                                </tr>
                                <tr>
                                  <td align="right">&nbsp;&nbsp;&nbsp;<span class="tabbot"> More Products .. </span> &nbsp;&nbsp;</td>
                                </tr>
                              </table>
                            </div></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td background="images/-Featured_products_bottom.jpg" style="background-repeat:no-repeat">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                </table></td>
                <td width="185" rowspan="2" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="left"><span class="style2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style3">Shopping Cart </span></span></td>
                        </tr>
                        <tr>
                          <td height="41" align="center" background="images/-rightside_body_bg.jpg" class="bold_txt1" style="background-repeat:repeat-y">No Boks<br />
                            Available in Cart </td>
                        </tr>
                        <tr>
                          <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
                        </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="add">Login</span></td>
                        </tr>
                        <tr>
                          <td background="images/-rightside_body_bg.jpg" style="background-repeat:repeat-y" align="center"><form id="form1" name="form1" method="post" action="">
                            <table width="100%" border="0" cellspacing="4" cellpadding="0">
                              <tr>
                                <td width="47%" align="right" class="brown_txt">UserName : </td>
                                <td width="53%" align="left"><input name="textfield" type="text" size="12" /></td>
                              </tr>
                              <tr>
                                <td align="right" class="brown_txt">Password : </td>
                                <td align="left"><input name="textfield2" type="text" size="12" /></td>
                              </tr>
                              <tr>
                                <td>&nbsp;</td>
                                <td align="left"><input type="submit" name="Submit" value="Submit" /></td>
                              </tr>
                              <tr>
                                <td colspan="2">&nbsp;</td>
                              </tr>
                            </table>
                                                    </form>                          </td>
                        </tr>
                        <tr>
                          <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
                        </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="add">Request call Back </span></td>
                        </tr>
                        <tr>
                          <td background="images/-rightside_body_bg.jpg" style="background-repeat:repeat-y" align="center"><form id="form2" name="form2" method="post" action="">
                            <table width="100%" border="0" cellspacing="4" cellpadding="0">
                              <tr>
                                <td width="47%" align="right" class="brown_txt">Name  : </td>
                                <td width="53%" align="left"><input name="textfield3" type="text" size="12" /></td>
                              </tr>
                              <tr>
                                <td align="right" class="brown_txt">Email : </td>
                                <td align="left"><input name="textfield22" type="text" size="12" /></td>
                              </tr>
                              <tr>
                                <td align="right" class="brown_txt">Reason : </td>
                                <td align="left"><textarea name="textfield22" cols="12"></textarea></td>
                              </tr>
                              <tr>
                                <td>&nbsp;</td>
                                <td><input type="submit" name="Submit2" value="Submit" /></td>
                              </tr>
                            </table>
                                                    </form>                          </td>
                        </tr>
                        <tr>
                          <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
                        </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td height="33" background="images/-rightside_heading_bg.jpg" style="background-repeat:no-repeat" align="center">&nbsp;</td>
                        </tr>
                        <tr>
                          <td background="images/-rightside_body_bg.jpg" style="background-repeat:repeat-y" align="center">&nbsp;</td>
                        </tr>
                        <tr>
                          <td><img src="images/main-banner_25years.jpg" width="182" height="9" /></td>
                        </tr>
                      </table></td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td colspan="2"><table width="762" border="0" cellspacing="0" cellpadding="0">
                  
                  <tr>
                    <td height="35" background="images/otherproducts_head.jpg" class="add">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Other Products </td>
                    </tr>
                  <tr>
                    <td background="images/bg_otherproducts.jpg" align="center" style="background-repeat:repeat-y"><table width="95%" border="0" align="center" cellpadding="0" cellspacing="2">
                      <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td align="center">&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width="25%"><table width="25%" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td><img src="images/book.jpg" width="109" height="148" /></td>
                            </tr>
                            <tr>
                              <td height="25" align="center" class="bold_txt">Mathematics</td>
                            </tr>
                        </table></td>
                        <td width="25%"><table width="25%" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td><img src="images/book.jpg" width="109" height="148" /></td>
                            </tr>
                            <tr>
                              <td height="25" align="center" class="bold_txt">Mathematics</td>
                            </tr>
                        </table></td>
                        <td width="25%" align="center"><table width="25%" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td><img src="images/book.jpg" width="109" height="148" /></td>
                          </tr>
                          <tr>
                            <td height="25" align="center" class="bold_txt">Mathematics</td>
                          </tr>
                        </table></td>
                        <td width="223"><table width="25%" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td><img src="images/book.jpg" width="109" height="148" /></td>
                          </tr>
                          <tr>
                            <td height="25" align="center" class="bold_txt">Mathematics</td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td align="center">&nbsp;</td>
                        <td align="right">&nbsp;&nbsp;<span class="tabbot"> More Products .. </span> &nbsp;&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td align="center" style="background-repeat:no-repeat"><img src="images/bg_otherproducts_bottom.jpg" width="766" height="11" /></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="80" valign="bottom" background="images/-footer.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="2%" align="center">&nbsp;</td>
        <td width="13%" align="right" class="maininfo">We Are Accept&nbsp;&nbsp; </td>
        <td colspan="2" align="left"><img src="images/credit-cards.jpg" width="161" height="22" /></td>
      </tr>
      <tr>
        <td align="center">&nbsp;</td>
        <td align="center" class="greentext">All Rights Reserved </td>
        <td width="69%" align="right" valign="middle" class="body-txt"><table width="98%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center">About Us | Contact Us | SiteMap</td>
          </tr>
        </table></td>
        <td width="16%" height="35" align="left" class="footertext">Powered By Srisolutions </td>
      </tr>
      <tr>
        <td colspan="4" align="center">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
